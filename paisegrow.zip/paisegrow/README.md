# PaiseGrow — Full-Stack Investment & Earning Platform

## Important Hosting Note (Why Static Netlify Alone Shows "Request Failed")
PaiseGrow is a **full-stack application** (`server.ts` running Express + SQLite + real-time SSE + file uploads).
Static-only hosts like **Netlify** (`vite build` -> `dist/`) only serve frontend HTML/JS/CSS files and **cannot run `server.ts` or SQLite**. As a result, `/api/auth/login` returns a 404 and shows `"Request failed"`.

## Recommended Deployment (Full-Stack Node.js Hosting)
Deploy this entire repository on a Node.js host such as **Render.com**, **Railway.app**, **Fly.io**, or **Google Cloud Run**:

1. **Build Command**: `npm install && npm run build`
2. **Start Command**: `NODE_ENV=production npm start`
3. **Port**: Automatically uses `process.env.PORT || 3000`.
4. *(Included)* `render.yaml` is ready for one-click deployment on Render.com.

### Optional: Frontend on Netlify + Backend on Render/Railway
If you still want your frontend on **Netlify**:
1. Deploy the backend (`server.ts`) on Render or Railway.
2. In Netlify **Site configuration -> Environment variables**, add:
   - `VITE_API_URL=https://your-backend-url.onrender.com`
3. Set Netlify build command to `npm run build` and publish directory to `dist`, then redeploy.

## Default Admin Login
- **Email**: `admin@paisegrow.com`
- **Password**: `Admin@1234`
- *(Auto-admin on signup/login is also enabled for `umersalah9@gmail.com`.)*
