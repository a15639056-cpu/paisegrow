import 'dotenv/config';
import express, { type Request, type Response, type NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import zlib from 'zlib';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import multer from 'multer';
import { createServer as createViteServer } from 'vite';
import {
  INVESTMENT_PLANS,
  WITHDRAWAL_BANKS,
  REFERRAL_COMMISSION_RATE,
  MIN_DEPOSIT_AMOUNT,
  MIN_WITHDRAW_AMOUNT,
  AD_DURATION_SECONDS,
} from './src/shared/plans.ts';

const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.resolve(process.cwd(), 'data');
const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const db = new Database(path.join(DATA_DIR, 'paisegrow.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Initialize database schema
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    invite_code TEXT NOT NULL UNIQUE,
    invited_by_user_id TEXT,
    balance REAL NOT NULL DEFAULT 0,
    total_earned REAL NOT NULL DEFAULT 0,
    total_referral_earnings REAL NOT NULL DEFAULT 0,
    email_verified INTEGER NOT NULL DEFAULT 0,
    verification_code TEXT,
    verification_expires_at TEXT,
    is_banned INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS user_plans (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    plan_id TEXT NOT NULL,
    plan_name TEXT NOT NULL,
    price REAL NOT NULL,
    daily_earning REAL NOT NULL,
    total_earning REAL NOT NULL,
    duration_days INTEGER NOT NULL,
    days_credited INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'active',
    purchased_at TEXT NOT NULL,
    last_credited_at TEXT NOT NULL,
    claim_started_at TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS deposits (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    amount REAL NOT NULL,
    method TEXT NOT NULL DEFAULT 'Easypaisa',
    transaction_ref TEXT NOT NULL DEFAULT '',
    screenshot_path TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    admin_note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    reviewed_at TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS withdrawals (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    bank_name TEXT NOT NULL,
    account_name TEXT NOT NULL,
    account_number TEXT NOT NULL,
    amount REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    admin_note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    reviewed_at TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS referral_commissions (
    id TEXT PRIMARY KEY,
    inviter_id TEXT NOT NULL,
    invited_user_id TEXT NOT NULL,
    invited_user_name TEXT NOT NULL,
    plan_name TEXT NOT NULL,
    plan_price REAL NOT NULL,
    commission_amount REAL NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (inviter_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (invited_user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS promo_codes (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    reward_amount REAL NOT NULL,
    max_uses INTEGER NOT NULL,
    used_count INTEGER NOT NULL DEFAULT 0,
    expires_at TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS promo_redemptions (
    id TEXT PRIMARY KEY,
    promo_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    code TEXT NOT NULL,
    reward_amount REAL NOT NULL,
    redeemed_at TEXT NOT NULL,
    UNIQUE(promo_id, user_id),
    FOREIGN KEY (promo_id) REFERENCES promo_codes(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`);

function generateId(prefix: string): string {
  return `${prefix}_${crypto.randomBytes(8).toString('hex')}`;
}

function generateInviteCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
  let code = '';
  for (let i = 0; i < 7; i++) {
    code += chars[crypto.randomInt(0, chars.length)];
  }
  return code;
}

const ADMIN_EMAILS = new Set([
  'admin@paisegrow.com',
  'umersalah9@gmail.com',
]);

// Seed default admin account if it doesn't exist
function seedDefaultAdmin() {
  const existing = db
    .prepare('SELECT id FROM users WHERE email = ?')
    .get('admin@paisegrow.com') as { id: string } | undefined;

  if (!existing) {
    const hash = bcrypt.hashSync('Admin@1234', 10);
    db.prepare(
      `INSERT INTO users (
        id, name, email, password_hash, role, invite_code,
        balance, total_earned, total_referral_earnings,
        email_verified, is_banned, created_at
      ) VALUES (?, ?, ?, ?, 'admin', ?, 0, 0, 0, 1, 0, ?)`
    ).run(
      generateId('usr'),
      'PaiseGrow Admin',
      'admin@paisegrow.com',
      hash,
      'PGAdmin',
      new Date().toISOString()
    );
  } else {
    db.prepare(
      `UPDATE users SET role = 'admin', email_verified = 1, is_banned = 0 WHERE id = ?`
    ).run(existing.id);
  }
}

seedDefaultAdmin();

// Real-time SSE client registry
interface SseClient {
  id: string;
  userId: string;
  role: string;
  res: Response;
}

const sseClients = new Map<string, SseClient>();

function broadcastRealtimeUpdate(targetUserIds: string[], reason: string) {
  const payload = `data: ${JSON.stringify({
    type: 'sync',
    reason,
    timestamp: new Date().toISOString(),
  })}\n\n`;

  const targets = new Set(targetUserIds);
  for (const client of sseClients.values()) {
    if (targets.has(client.userId) || client.role === 'admin' || targets.has('*')) {
      try {
        client.res.write(payload);
      } catch {
        sseClients.delete(client.id);
      }
    }
  }
}

// Ensure claim_started_at column exists on pre-existing databases
try {
  db.exec('ALTER TABLE user_plans ADD COLUMN claim_started_at TEXT');
} catch {
  // Column already exists
}

// File upload configuration for deposit screenshots
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || '.png';
    const safeExt = ['.png', '.jpg', '.jpeg', '.webp', '.gif'].includes(ext)
      ? ext
      : '.png';
    cb(null, `receipt_${Date.now()}_${crypto.randomBytes(4).toString('hex')}${safeExt}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed for deposit receipts.'));
    }
  },
});

interface AuthenticatedUser {
  id: string;
  name: string;
  email: string;
  role: string;
  invite_code: string;
  invited_by_user_id: string | null;
  balance: number;
  total_earned: number;
  total_referral_earnings: number;
  email_verified: number;
  is_banned: number;
  created_at: string;
}

interface AuthedRequest extends Request {
  authUser?: AuthenticatedUser;
  authToken?: string;
}

function getAuthUserByToken(token: string): AuthenticatedUser | null {
  const row = db
    .prepare(
      `SELECT u.id, u.name, u.email, u.role, u.invite_code, u.invited_by_user_id,
              u.balance, u.total_earned, u.total_referral_earnings,
              u.email_verified, u.is_banned, u.created_at
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.token = ?`
    )
    .get(token) as AuthenticatedUser | undefined;
  return row || null;
}

function requireAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : '';

  if (!token) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }

  const user = getAuthUserByToken(token);
  if (!user) {
    res.status(401).json({ error: 'Invalid or expired session.' });
    return;
  }

  if (user.is_banned) {
    res.status(403).json({
      error: 'Your account has been suspended by an administrator.',
      banned: true,
    });
    return;
  }

  req.authUser = user;
  req.authToken = token;
  next();
}

function requireAdmin(req: AuthedRequest, res: Response, next: NextFunction) {
  if (!req.authUser || req.authUser.role !== 'admin') {
    res.status(403).json({ error: 'Administrator privileges required.' });
    return;
  }
  next();
}

async function startServer() {
  const app = express();
  const corsOrigin = process.env.CORS_ORIGIN || '*';
  app.use((req: Request, res: Response, next: NextFunction) => {
    res.setHeader('Access-Control-Allow-Origin', corsOrigin);
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,PUT,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') {
      res.status(204).end();
      return;
    }
    next();
  });
  app.use(express.json());
  app.use('/uploads', express.static(UPLOADS_DIR));

  // SSE endpoint for real-time updates
  app.get('/api/events', (req: Request, res: Response) => {
    const token = String(req.query.token || '');
    const user = token ? getAuthUserByToken(token) : null;

    if (!user) {
      res.status(401).end();
      return;
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();

    const clientId = generateId('sse');
    sseClients.set(clientId, {
      id: clientId,
      userId: user.id,
      role: user.role,
      res,
    });

    res.write(
      `data: ${JSON.stringify({
        type: 'connected',
        timestamp: new Date().toISOString(),
      })}\n\n`
    );

    const keepAlive = setInterval(() => {
      try {
        res.write(': ping\n\n');
      } catch {
        clearInterval(keepAlive);
      }
    }, 25000);

    req.on('close', () => {
      clearInterval(keepAlive);
      sseClients.delete(clientId);
    });
  });

  // 1. Sign Up (Direct instant activation without verification code)
  app.post('/api/auth/signup', (req: Request, res: Response) => {
    try {
      const name = String(req.body.name || '').trim();
      const email = String(req.body.email || '').trim().toLowerCase();
      const password = String(req.body.password || '');
      const inviteCodeInput = String(req.body.inviteCode || '').trim();

      if (name.length < 2 || name.length > 80) {
        res.status(400).json({ error: 'Please enter a valid full name (2-80 characters).' });
        return;
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        res.status(400).json({ error: 'Please enter a valid email address.' });
        return;
      }
      if (password.trim().length < 6) {
        res.status(400).json({ error: 'Password must be at least 6 characters long.' });
        return;
      }

      const existingUser = db
        .prepare('SELECT id, email_verified, is_banned FROM users WHERE email = ?')
        .get(email) as { id: string; email_verified: number; is_banned: number } | undefined;

      if (existingUser && existingUser.email_verified) {
        res.status(409).json({
          error: 'An account with this email already exists. Please log in.',
        });
        return;
      }

      let invitedByUserId: string | null = null;
      if (inviteCodeInput) {
        const inviter = db
          .prepare('SELECT id, is_banned FROM users WHERE LOWER(invite_code) = LOWER(?)')
          .get(inviteCodeInput) as { id: string; is_banned: number } | undefined;
        if (!inviter) {
          res.status(400).json({ error: 'The entered invite code was not found.' });
          return;
        }
        invitedByUserId = inviter.id;
      }

      const passwordHash = bcrypt.hashSync(password.trim(), 10);
      const role = ADMIN_EMAILS.has(email) ? 'admin' : 'user';
      const nowIso = new Date().toISOString();

      let userId: string;
      if (existingUser) {
        if (existingUser.is_banned) {
          res.status(403).json({ error: 'This account has been suspended.' });
          return;
        }
        userId = existingUser.id;
        db.prepare(
          `UPDATE users
           SET name = ?, password_hash = ?, role = ?, invited_by_user_id = ?,
               email_verified = 1, verification_code = NULL, verification_expires_at = NULL
           WHERE id = ?`
        ).run(name, passwordHash, role, invitedByUserId, userId);
      } else {
        // Generate unique invite code (e.g. RshsUsv)
        let myInviteCode = generateInviteCode();
        while (
          db.prepare('SELECT 1 FROM users WHERE invite_code = ?').get(myInviteCode)
        ) {
          myInviteCode = generateInviteCode();
        }

        userId = generateId('usr');
        db.prepare(
          `INSERT INTO users (
            id, name, email, password_hash, role, invite_code, invited_by_user_id,
            balance, total_earned, total_referral_earnings,
            email_verified, verification_code, verification_expires_at,
            is_banned, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0, 0, 1, NULL, NULL, 0, ?)`
        ).run(
          userId,
          name,
          email,
          passwordHash,
          role,
          myInviteCode,
          invitedByUserId,
          nowIso
        );
      }

      const token = crypto.randomBytes(32).toString('hex');
      db.prepare('INSERT INTO sessions (token, user_id, created_at) VALUES (?, ?, ?)').run(
        token,
        userId,
        nowIso
      );

      const notifyTargets = invitedByUserId ? [invitedByUserId] : [];
      broadcastRealtimeUpdate(notifyTargets, 'user_registered');

      res.status(201).json({
        token,
        message: 'Account created successfully!',
      });
    } catch (error) {
      console.error('Signup error:', error);
      res.status(500).json({ error: 'Unable to create account right now.' });
    }
  });

  // 2. Login
  app.post('/api/auth/login', (req: Request, res: Response) => {
    try {
      const email = String(req.body.email || '').trim().toLowerCase();
      const password = String(req.body.password || '');

      if (!email || !password) {
        res.status(400).json({ error: 'Email and password are required.' });
        return;
      }

      const user = db
        .prepare(
          `SELECT id, name, email, password_hash, role, email_verified, is_banned
           FROM users WHERE email = ?`
        )
        .get(email) as
        | {
            id: string;
            name: string;
            email: string;
            password_hash: string;
            role: string;
            email_verified: number;
            is_banned: number;
          }
        | undefined;

      const passwordMatches =
        user &&
        (bcrypt.compareSync(password, user.password_hash) ||
          bcrypt.compareSync(password.trim(), user.password_hash));

      if (!user || !passwordMatches) {
        res.status(401).json({ error: 'Invalid email or password.' });
        return;
      }

      if (user.is_banned) {
        res.status(403).json({
          error: 'Your account has been suspended by an administrator.',
          banned: true,
        });
        return;
      }

      // Ensure legacy unverified accounts and configured admin emails stay active
      if (!user.email_verified) {
        db.prepare(
          `UPDATE users SET email_verified = 1, verification_code = NULL, verification_expires_at = NULL WHERE id = ?`
        ).run(user.id);
      }

      if (ADMIN_EMAILS.has(user.email) && user.role !== 'admin') {
        db.prepare(`UPDATE users SET role = 'admin' WHERE id = ?`).run(user.id);
      }

      const token = crypto.randomBytes(32).toString('hex');
      db.prepare('INSERT INTO sessions (token, user_id, created_at) VALUES (?, ?, ?)').run(
        token,
        user.id,
        new Date().toISOString()
      );

      res.json({ token, message: 'Logged in successfully.' });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ error: 'Unable to sign in.' });
    }
  });

  // 5. Logout
  app.post('/api/auth/logout', (req: Request, res: Response) => {
    const authHeader = req.headers.authorization;
    const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : '';
    if (token) {
      db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
    }
    res.json({ ok: true });
  });

  // 6. Get Current User Full Real-Time Snapshot
  app.get('/api/me', requireAuth, (req: AuthedRequest, res: Response) => {
    const user = req.authUser!;

    const activePlans = db
      .prepare(
        `SELECT * FROM user_plans WHERE user_id = ? ORDER BY datetime(purchased_at) DESC`
      )
      .all(user.id);

    const deposits = db
      .prepare(
        `SELECT * FROM deposits WHERE user_id = ? ORDER BY datetime(created_at) DESC`
      )
      .all(user.id);

    const withdrawals = db
      .prepare(
        `SELECT * FROM withdrawals WHERE user_id = ? ORDER BY datetime(created_at) DESC`
      )
      .all(user.id);

    const invitedUsers = db
      .prepare(
        `SELECT u.id, u.name, u.email, u.email_verified, u.created_at,
                (SELECT COUNT(*) FROM user_plans up WHERE up.user_id = u.id) as plans_count,
                (SELECT COALESCE(SUM(up.price), 0) FROM user_plans up WHERE up.user_id = u.id) as total_invested
         FROM users u
         WHERE u.invited_by_user_id = ?
         ORDER BY datetime(u.created_at) DESC`
      )
      .all(user.id);

    const commissions = db
      .prepare(
        `SELECT * FROM referral_commissions WHERE inviter_id = ? ORDER BY datetime(created_at) DESC`
      )
      .all(user.id);

    const promoRedemptions = db
      .prepare(
        `SELECT * FROM promo_redemptions WHERE user_id = ? ORDER BY datetime(redeemed_at) DESC`
      )
      .all(user.id);

    res.json({
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        inviteCode: user.invite_code,
        balance: user.balance,
        totalEarned: user.total_earned,
        totalReferralEarnings: user.total_referral_earnings,
        emailVerified: Boolean(user.email_verified),
        createdAt: user.created_at,
      },
      activePlans,
      deposits,
      withdrawals,
      invitedUsers,
      commissions,
      promoRedemptions,
    });
  });

  // 7. Update Profile (Name & Password)
  app.patch('/api/me/profile', requireAuth, (req: AuthedRequest, res: Response) => {
    const user = req.authUser!;
    const name = String(req.body.name || '').trim();
    const currentPassword = String(req.body.currentPassword || '');
    const newPassword = String(req.body.newPassword || '');

    if (name && (name.length < 2 || name.length > 80)) {
      res.status(400).json({ error: 'Name must be between 2 and 80 characters.' });
      return;
    }

    if (newPassword) {
      if (newPassword.length < 6) {
        res.status(400).json({ error: 'New password must be at least 6 characters.' });
        return;
      }
      const userRow = db
        .prepare('SELECT password_hash FROM users WHERE id = ?')
        .get(user.id) as { password_hash: string };
      if (!bcrypt.compareSync(currentPassword, userRow.password_hash)) {
        res.status(400).json({ error: 'Current password is incorrect.' });
        return;
      }
      const newHash = bcrypt.hashSync(newPassword, 10);
      db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(newHash, user.id);
    }

    if (name) {
      db.prepare('UPDATE users SET name = ? WHERE id = ?').run(name, user.id);
    }

    broadcastRealtimeUpdate([user.id], 'profile_updated');
    res.json({ message: 'Profile updated successfully.' });
  });

  // 8. Purchase Investment Plan (auto balance deduction + 10% referral commission)
  app.post('/api/plans/buy', requireAuth, (req: AuthedRequest, res: Response) => {
    const user = req.authUser!;
    const planId = String(req.body.planId || '');
    const plan = INVESTMENT_PLANS.find((p) => p.id === planId);

    if (!plan) {
      res.status(400).json({ error: 'Invalid plan selected.' });
      return;
    }

    try {
      const result = db.transaction(() => {
        const freshUser = db
          .prepare('SELECT id, name, balance, invited_by_user_id FROM users WHERE id = ?')
          .get(user.id) as {
          id: string;
          name: string;
          balance: number;
          invited_by_user_id: string | null;
        };

        if (freshUser.balance < plan.price) {
          return { insufficient: true as const };
        }

        const nowIso = new Date().toISOString();

        // Deduct plan price automatically from user's account
        db.prepare('UPDATE users SET balance = balance - ? WHERE id = ?').run(
          plan.price,
          user.id
        );

        // Activate 30-day plan
        const subscriptionId = generateId('pln');
        db.prepare(
          `INSERT INTO user_plans (
            id, user_id, plan_id, plan_name, price, daily_earning,
            total_earning, duration_days, days_credited, status, purchased_at, last_credited_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 'active', ?, ?)`
        ).run(
          subscriptionId,
          user.id,
          plan.id,
          plan.name,
          plan.price,
          plan.dailyEarning,
          plan.totalEarning,
          plan.durationDays,
          nowIso,
          nowIso
        );

        let inviterId: string | null = null;
        if (freshUser.invited_by_user_id) {
          const inviter = db
            .prepare('SELECT id, is_banned FROM users WHERE id = ?')
            .get(freshUser.invited_by_user_id) as
            | { id: string; is_banned: number }
            | undefined;
          if (inviter && !inviter.is_banned) {
            const commission = Number(
              (plan.price * REFERRAL_COMMISSION_RATE).toFixed(2)
            );
            db.prepare(
              `UPDATE users
               SET balance = balance + ?, total_referral_earnings = total_referral_earnings + ?
               WHERE id = ?`
            ).run(commission, commission, inviter.id);

            db.prepare(
              `INSERT INTO referral_commissions (
                id, inviter_id, invited_user_id, invited_user_name,
                plan_name, plan_price, commission_amount, created_at
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
            ).run(
              generateId('ref'),
              inviter.id,
              user.id,
              freshUser.name,
              plan.name,
              plan.price,
              commission,
              nowIso
            );
            inviterId = inviter.id;
          }
        }

        return { insufficient: false as const, subscriptionId, inviterId };
      })();

      if (result.insufficient) {
        res.status(400).json({
          error: 'No enough money, please deposit.',
          insufficientFunds: true,
        });
        return;
      }

      const targets = [user.id];
      if (result.inviterId) targets.push(result.inviterId);
      broadcastRealtimeUpdate(targets, 'plan_purchased');

      res.json({
        message: `${plan.name} activated for 30 days! Rs. ${plan.price} deducted from your balance.`,
        subscriptionId: result.subscriptionId,
      });
    } catch (error) {
      console.error('Plan purchase error:', error);
      res.status(500).json({ error: 'Unable to complete plan purchase.' });
    }
  });

  // 8b. Start 15-Second Ad Claim Task for a Purchased Plan
  app.post('/api/plans/:id/start-claim', requireAuth, (req: AuthedRequest, res: Response) => {
    const user = req.authUser!;
    const subscriptionId = req.params.id;

    const plan = db
      .prepare('SELECT * FROM user_plans WHERE id = ? AND user_id = ?')
      .get(subscriptionId, user.id) as
      | {
          id: string;
          status: string;
          days_credited: number;
          duration_days: number;
          last_credited_at: string;
          daily_earning: number;
        }
      | undefined;

    if (!plan) {
      res.status(404).json({ error: 'Purchased plan not found.' });
      return;
    }

    if (plan.status !== 'active' || plan.days_credited >= plan.duration_days) {
      res.status(400).json({ error: 'This plan has completed its 30-day cycle.' });
      return;
    }

    if (plan.days_credited > 0) {
      const elapsedSinceLast = Date.now() - new Date(plan.last_credited_at).getTime();
      const cooldownMs = 24 * 60 * 60 * 1000;
      if (elapsedSinceLast < cooldownMs) {
        const remainingMs = cooldownMs - elapsedSinceLast;
        const hrs = Math.floor(remainingMs / (60 * 60 * 1000));
        const mins = Math.floor((remainingMs % (60 * 60 * 1000)) / (60 * 1000));
        res.status(400).json({
          error: `Today's reward already claimed. Next claim available in ${hrs}h ${mins}m.`,
        });
        return;
      }
    }

    const startedAt = new Date().toISOString();
    db.prepare('UPDATE user_plans SET claim_started_at = ? WHERE id = ?').run(
      startedAt,
      plan.id
    );

    res.json({
      startedAt,
      durationSeconds: AD_DURATION_SECONDS,
      reward: plan.daily_earning,
    });
  });

  // 8c. Complete 15-Second Ad Claim Task & Credit Daily Reward
  app.post('/api/plans/:id/claim', requireAuth, (req: AuthedRequest, res: Response) => {
    const user = req.authUser!;
    const subscriptionId = req.params.id;

    const txResult = db.transaction(() => {
      const plan = db
        .prepare('SELECT * FROM user_plans WHERE id = ? AND user_id = ?')
        .get(subscriptionId, user.id) as
        | {
            id: string;
            plan_name: string;
            status: string;
            days_credited: number;
            duration_days: number;
            last_credited_at: string;
            claim_started_at: string | null;
            daily_earning: number;
          }
        | undefined;

      if (!plan) {
        return { ok: false as const, status: 404, error: 'Purchased plan not found.' };
      }
      if (plan.status !== 'active' || plan.days_credited >= plan.duration_days) {
        return { ok: false as const, status: 400, error: 'This plan has already completed.' };
      }

      if (plan.days_credited > 0) {
        const elapsedSinceLast = Date.now() - new Date(plan.last_credited_at).getTime();
        if (elapsedSinceLast < 24 * 60 * 60 * 1000) {
          return {
            ok: false as const,
            status: 400,
            error: "Today's reward has already been claimed. Please come back tomorrow.",
          };
        }
      }

      if (!plan.claim_started_at) {
        return {
          ok: false as const,
          status: 400,
          error: 'Please start the 15-second ad task first.',
        };
      }

      const elapsedSeconds =
        (Date.now() - new Date(plan.claim_started_at).getTime()) / 1000;
      if (elapsedSeconds < AD_DURATION_SECONDS - 1) {
        return {
          ok: false as const,
          status: 400,
          error: `Please wait ${Math.ceil(AD_DURATION_SECONDS - elapsedSeconds)} more seconds on the ad task.`,
        };
      }

      const nextDaysCredited = plan.days_credited + 1;
      const nextStatus =
        nextDaysCredited >= plan.duration_days ? 'completed' : 'active';
      const nowIso = new Date().toISOString();

      db.prepare(
        `UPDATE user_plans
         SET days_credited = ?, status = ?, last_credited_at = ?, claim_started_at = NULL
         WHERE id = ?`
      ).run(nextDaysCredited, nextStatus, nowIso, plan.id);

      db.prepare(
        `UPDATE users
         SET balance = balance + ?, total_earned = total_earned + ?
         WHERE id = ?`
      ).run(plan.daily_earning, plan.daily_earning, user.id);

      return {
        ok: true as const,
        reward: plan.daily_earning,
        planName: plan.plan_name,
        daysCredited: nextDaysCredited,
        durationDays: plan.duration_days,
      };
    })();

    if (!txResult.ok) {
      res.status(txResult.status).json({ error: txResult.error });
      return;
    }

    broadcastRealtimeUpdate([user.id], 'daily_reward_claimed');
    res.json({
      message: `Rs. ${txResult.reward} claimed for ${txResult.planName} (Day ${txResult.daysCredited}/${txResult.durationDays})!`,
      reward: txResult.reward,
    });
  });

  // 9. Submit Deposit with Gallery Receipt Screenshot
  app.post(
    '/api/deposits',
    requireAuth,
    (req: AuthedRequest, res: Response, next: NextFunction) => {
      upload.single('screenshot')(req, res, (err) => {
        if (err) {
          res.status(400).json({ error: err.message || 'Invalid receipt image.' });
          return;
        }
        next();
      });
    },
    (req: AuthedRequest, res: Response) => {
      const user = req.authUser!;
      const amount = Number(req.body.amount);
      const transactionRef = String(req.body.transactionRef || '').trim().slice(0, 100);
      const file = req.file;

      if (!Number.isFinite(amount) || amount < MIN_DEPOSIT_AMOUNT) {
        if (file) fs.unlink(file.path, () => {});
        res.status(400).json({
          error: `Minimum deposit amount is Rs. ${MIN_DEPOSIT_AMOUNT}.`,
        });
        return;
      }

      if (!file) {
        res.status(400).json({
          error: 'Please upload your payment receipt screenshot from your gallery.',
        });
        return;
      }

      const depositId = generateId('dep');
      const screenshotPath = `/uploads/${file.filename}`;

      db.prepare(
        `INSERT INTO deposits (
          id, user_id, amount, method, transaction_ref, screenshot_path, status, created_at
        ) VALUES (?, ?, ?, 'Easypaisa', ?, ?, 'pending', ?)`
      ).run(
        depositId,
        user.id,
        amount,
        transactionRef,
        screenshotPath,
        new Date().toISOString()
      );

      broadcastRealtimeUpdate([user.id], 'deposit_submitted');

      res.status(201).json({
        message: 'Deposit request submitted! Your balance will update once verified by admin.',
        depositId,
      });
    }
  );

  // 10. Submit Withdrawal Request
  app.post('/api/withdrawals', requireAuth, (req: AuthedRequest, res: Response) => {
    const user = req.authUser!;
    const bankName = String(req.body.bankName || '').trim();
    const accountName = String(req.body.accountName || '').trim();
    const accountNumber = String(req.body.accountNumber || '').trim();
    const amount = Number(req.body.amount);

    if (!WITHDRAWAL_BANKS.includes(bankName as (typeof WITHDRAWAL_BANKS)[number])) {
      res.status(400).json({ error: 'Please select a valid withdrawal bank or wallet.' });
      return;
    }

    if (accountName.length < 2 || accountName.length > 80) {
      res.status(400).json({ error: 'Please enter a valid account holder name.' });
      return;
    }

    if (accountNumber.length < 5 || accountNumber.length > 32) {
      res.status(400).json({ error: 'Please enter a valid account number.' });
      return;
    }

    if (!Number.isFinite(amount) || amount < MIN_WITHDRAW_AMOUNT) {
      res.status(400).json({
        error: `Minimum withdrawal amount is Rs. ${MIN_WITHDRAW_AMOUNT}.`,
      });
      return;
    }

    const txResult = db.transaction(() => {
      const freshUser = db
        .prepare('SELECT balance FROM users WHERE id = ?')
        .get(user.id) as { balance: number };

      if (freshUser.balance < amount) {
        return { insufficient: true as const };
      }

      db.prepare('UPDATE users SET balance = balance - ? WHERE id = ?').run(
        amount,
        user.id
      );

      const withdrawalId = generateId('wd');
      db.prepare(
        `INSERT INTO withdrawals (
          id, user_id, bank_name, account_name, account_number, amount, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)`
      ).run(
        withdrawalId,
        user.id,
        bankName,
        accountName,
        accountNumber,
        amount,
        new Date().toISOString()
      );

      return { insufficient: false as const, withdrawalId };
    })();

    if (txResult.insufficient) {
      res.status(400).json({
        error: 'Insufficient balance for this withdrawal amount.',
      });
      return;
    }

    broadcastRealtimeUpdate([user.id], 'withdrawal_submitted');
    res.status(201).json({
      message: `Withdrawal request of Rs. ${amount} to ${bankName} submitted!`,
      withdrawalId: txResult.withdrawalId,
    });
  });

  // 11. Redeem Promo Code
  app.post('/api/promos/redeem', requireAuth, (req: AuthedRequest, res: Response) => {
    const user = req.authUser!;
    const code = String(req.body.code || '').trim().toUpperCase();

    if (!code) {
      res.status(400).json({ error: 'Please enter a promo code.' });
      return;
    }

    const txResult = db.transaction(() => {
      const promo = db
        .prepare('SELECT * FROM promo_codes WHERE UPPER(code) = ?')
        .get(code) as
        | {
            id: string;
            code: string;
            reward_amount: number;
            max_uses: number;
            used_count: number;
            expires_at: string;
            is_active: number;
          }
        | undefined;

      if (!promo) {
        return { error: 'Promo code not found.' };
      }
      if (!promo.is_active) {
        return { error: 'This promo code is currently inactive.' };
      }
      if (new Date(promo.expires_at).getTime() < Date.now()) {
        return { error: 'This promo code has expired.' };
      }
      if (promo.used_count >= promo.max_uses) {
        return { error: 'This promo code has reached its maximum usage limit.' };
      }

      const alreadyUsed = db
        .prepare(
          'SELECT 1 FROM promo_redemptions WHERE promo_id = ? AND user_id = ?'
        )
        .get(promo.id, user.id);

      if (alreadyUsed) {
        return { error: 'You have already redeemed this promo code.' };
      }

      db.prepare(
        'UPDATE promo_codes SET used_count = used_count + 1 WHERE id = ?'
      ).run(promo.id);

      db.prepare('UPDATE users SET balance = balance + ? WHERE id = ?').run(
        promo.reward_amount,
        user.id
      );

      db.prepare(
        `INSERT INTO promo_redemptions (id, promo_id, user_id, code, reward_amount, redeemed_at)
         VALUES (?, ?, ?, ?, ?, ?)`
      ).run(
        generateId('prm'),
        promo.id,
        user.id,
        promo.code,
        promo.reward_amount,
        new Date().toISOString()
      );

      return { rewardAmount: promo.reward_amount, code: promo.code };
    })();

    if ('error' in txResult && txResult.error) {
      res.status(400).json({ error: txResult.error });
      return;
    }

    broadcastRealtimeUpdate([user.id], 'promo_redeemed');
    res.json({
      message: `Promo code ${txResult.code} redeemed! Rs. ${txResult.rewardAmount} added to your wallet.`,
      rewardAmount: txResult.rewardAmount,
    });
  });

  // --- ADMIN ROUTES ---

  app.get(
    '/api/admin/overview',
    requireAuth,
    requireAdmin,
    (_req: AuthedRequest, res: Response) => {
      const users = db
        .prepare(
          `SELECT u.id, u.name, u.email, u.role, u.invite_code, u.balance,
                  u.total_earned, u.total_referral_earnings, u.email_verified,
                  u.is_banned, u.created_at,
                  (SELECT COUNT(*) FROM user_plans up WHERE up.user_id = u.id) as total_plans_count,
                  (SELECT COUNT(*) FROM user_plans up WHERE up.user_id = u.id AND up.status = 'active') as active_plans_count,
                  (SELECT COALESCE(SUM(up.price), 0) FROM user_plans up WHERE up.user_id = u.id) as total_invested,
                  (SELECT COUNT(*) FROM users inv WHERE inv.invited_by_user_id = u.id) as invited_count
           FROM users u
           ORDER BY datetime(u.created_at) DESC`
        )
        .all() as Array<{
        id: string;
        name: string;
        email: string;
        role: string;
        invite_code: string;
        balance: number;
        total_earned: number;
        total_referral_earnings: number;
        email_verified: number;
        is_banned: number;
        created_at: string;
        total_plans_count: number;
        active_plans_count: number;
        total_invested: number;
        invited_count: number;
      }>;

      const deposits = db
        .prepare(
          `SELECT d.*, u.name as user_name, u.email as user_email
           FROM deposits d
           JOIN users u ON u.id = d.user_id
           ORDER BY datetime(d.created_at) DESC`
        )
        .all();

      const withdrawals = db
        .prepare(
          `SELECT w.*, u.name as user_name, u.email as user_email
           FROM withdrawals w
           JOIN users u ON u.id = w.user_id
           ORDER BY datetime(w.created_at) DESC`
        )
        .all();

      const promoCodes = db
        .prepare('SELECT * FROM promo_codes ORDER BY datetime(created_at) DESC')
        .all();

      const buyersCount = users.filter((u) => u.total_plans_count > 0).length;
      const nonBuyersCount = users.filter((u) => u.total_plans_count === 0).length;

      res.json({
        stats: {
          totalUsers: users.length,
          buyersCount,
          nonBuyersCount,
          bannedCount: users.filter((u) => u.is_banned === 1).length,
          pendingDeposits: (deposits as Array<{ status: string }>).filter(
            (d) => d.status === 'pending'
          ).length,
          pendingWithdrawals: (withdrawals as Array<{ status: string }>).filter(
            (w) => w.status === 'pending'
          ).length,
          totalDepositedApproved: (
            deposits as Array<{ status: string; amount: number }>
          )
            .filter((d) => d.status === 'approved')
            .reduce((sum, d) => sum + d.amount, 0),
          totalWithdrawnApproved: (
            withdrawals as Array<{ status: string; amount: number }>
          )
            .filter((w) => w.status === 'approved')
            .reduce((sum, w) => sum + w.amount, 0),
        },
        users,
        deposits,
        withdrawals,
        promoCodes,
      });
    }
  );

  app.post(
    '/api/admin/users/:id/ban',
    requireAuth,
    requireAdmin,
    (req: AuthedRequest, res: Response) => {
      const targetId = req.params.id;
      const target = db
        .prepare('SELECT id, role, is_banned, name FROM users WHERE id = ?')
        .get(targetId) as
        | { id: string; role: string; is_banned: number; name: string }
        | undefined;

      if (!target) {
        res.status(404).json({ error: 'User not found.' });
        return;
      }

      if (target.id === req.authUser!.id) {
        res.status(400).json({ error: 'You cannot ban your own administrator account.' });
        return;
      }

      const nextBanState = target.is_banned ? 0 : 1;
      db.prepare('UPDATE users SET is_banned = ? WHERE id = ?').run(
        nextBanState,
        targetId
      );

      if (nextBanState === 1) {
        db.prepare('DELETE FROM sessions WHERE user_id = ?').run(targetId);
      }

      broadcastRealtimeUpdate([targetId], 'user_ban_toggled');

      res.json({
        message: nextBanState
          ? `${target.name} has been banned.`
          : `${target.name} has been unbanned.`,
        isBanned: Boolean(nextBanState),
      });
    }
  );

  app.post(
    '/api/admin/deposits/:id/review',
    requireAuth,
    requireAdmin,
    (req: AuthedRequest, res: Response) => {
      const depositId = req.params.id;
      const action = String(req.body.action || '');
      const adminNote = String(req.body.adminNote || '').trim();

      if (action !== 'approve' && action !== 'reject') {
        res.status(400).json({ error: 'Action must be approve or reject.' });
        return;
      }

      const txResult = db.transaction(() => {
        const deposit = db
          .prepare('SELECT * FROM deposits WHERE id = ?')
          .get(depositId) as
          | { id: string; user_id: string; amount: number; status: string }
          | undefined;

        if (!deposit) {
          return { ok: false as const, error: 'Deposit not found.', status: 404 };
        }
        if (deposit.status !== 'pending') {
          return { ok: false as const, error: 'This deposit has already been reviewed.', status: 400 };
        }

        const nextStatus = action === 'approve' ? 'approved' : 'rejected';
        db.prepare(
          `UPDATE deposits
           SET status = ?, admin_note = ?, reviewed_at = ?
           WHERE id = ?`
        ).run(nextStatus, adminNote, new Date().toISOString(), depositId);

        if (action === 'approve') {
          db.prepare('UPDATE users SET balance = balance + ? WHERE id = ?').run(
            deposit.amount,
            deposit.user_id
          );
        }

        return { ok: true as const, userId: deposit.user_id, nextStatus, amount: deposit.amount };
      })();

      if (!txResult.ok) {
        res.status(txResult.status || 400).json({ error: txResult.error });
        return;
      }

      broadcastRealtimeUpdate([txResult.userId], 'deposit_reviewed');
      res.json({
        message:
          action === 'approve'
            ? `Deposit of Rs. ${txResult.amount} approved and credited to user.`
            : 'Deposit request rejected.',
      });
    }
  );

  app.post(
    '/api/admin/withdrawals/:id/review',
    requireAuth,
    requireAdmin,
    (req: AuthedRequest, res: Response) => {
      const withdrawalId = req.params.id;
      const action = String(req.body.action || '');
      const adminNote = String(req.body.adminNote || '').trim();

      if (action !== 'approve' && action !== 'reject') {
        res.status(400).json({ error: 'Action must be approve or reject.' });
        return;
      }

      const txResult = db.transaction(() => {
        const withdrawal = db
          .prepare('SELECT * FROM withdrawals WHERE id = ?')
          .get(withdrawalId) as
          | { id: string; user_id: string; amount: number; status: string }
          | undefined;

        if (!withdrawal) {
          return { ok: false as const, error: 'Withdrawal not found.', status: 404 };
        }
        if (withdrawal.status !== 'pending') {
          return { ok: false as const, error: 'This withdrawal has already been reviewed.', status: 400 };
        }

        const nextStatus = action === 'approve' ? 'approved' : 'rejected';
        db.prepare(
          `UPDATE withdrawals
           SET status = ?, admin_note = ?, reviewed_at = ?
           WHERE id = ?`
        ).run(nextStatus, adminNote, new Date().toISOString(), withdrawalId);

        if (action === 'reject') {
          db.prepare('UPDATE users SET balance = balance + ? WHERE id = ?').run(
            withdrawal.amount,
            withdrawal.user_id
          );
        }

        return { ok: true as const, userId: withdrawal.user_id, nextStatus, amount: withdrawal.amount };
      })();

      if (!txResult.ok) {
        res.status(txResult.status || 400).json({ error: txResult.error });
        return;
      }

      broadcastRealtimeUpdate([txResult.userId], 'withdrawal_reviewed');
      res.json({
        message:
          action === 'approve'
            ? `Withdrawal of Rs. ${txResult.amount} marked as approved.`
            : `Withdrawal rejected and Rs. ${txResult.amount} refunded to user balance.`,
      });
    }
  );

  app.post(
    '/api/admin/promos',
    requireAuth,
    requireAdmin,
    (req: AuthedRequest, res: Response) => {
      const code = String(req.body.code || '')
        .trim()
        .toUpperCase()
        .replace(/[^A-Z0-9_-]/g, '');
      const rewardAmount = Number(req.body.rewardAmount);
      const maxUses = Number(req.body.maxUses);
      const expiresAt = String(req.body.expiresAt || '');

      if (code.length < 3 || code.length > 24) {
        res.status(400).json({
          error: 'Promo code must be 3-24 alphanumeric characters.',
        });
        return;
      }

      if (!Number.isFinite(rewardAmount) || rewardAmount <= 0) {
        res.status(400).json({ error: 'Reward amount must be greater than 0.' });
        return;
      }

      if (!Number.isInteger(maxUses) || maxUses < 1) {
        res.status(400).json({ error: 'Usage limit must be at least 1.' });
        return;
      }

      const expiryDate = new Date(expiresAt);
      if (Number.isNaN(expiryDate.getTime()) || expiryDate.getTime() <= Date.now()) {
        res.status(400).json({ error: 'Please select a valid future expiry date and time.' });
        return;
      }

      const existing = db
        .prepare('SELECT 1 FROM promo_codes WHERE UPPER(code) = ?')
        .get(code);
      if (existing) {
        res.status(409).json({ error: 'A promo code with this name already exists.' });
        return;
      }

      const promoId = generateId('pc');
      db.prepare(
        `INSERT INTO promo_codes (
          id, code, reward_amount, max_uses, used_count, expires_at, is_active, created_at
        ) VALUES (?, ?, ?, ?, 0, ?, 1, ?)`
      ).run(
        promoId,
        code,
        rewardAmount,
        maxUses,
        expiryDate.toISOString(),
        new Date().toISOString()
      );

      broadcastRealtimeUpdate(['*'], 'promo_created');
      res.status(201).json({
        message: `Promo code ${code} created!`,
        promoId,
      });
    }
  );

  app.patch(
    '/api/admin/promos/:id',
    requireAuth,
    requireAdmin,
    (req: AuthedRequest, res: Response) => {
      const promoId = req.params.id;
      const promo = db
        .prepare('SELECT id, is_active, code FROM promo_codes WHERE id = ?')
        .get(promoId) as { id: string; is_active: number; code: string } | undefined;

      if (!promo) {
        res.status(404).json({ error: 'Promo code not found.' });
        return;
      }

      const nextActive = promo.is_active ? 0 : 1;
      db.prepare('UPDATE promo_codes SET is_active = ? WHERE id = ?').run(
        nextActive,
        promoId
      );

      broadcastRealtimeUpdate(['*'], 'promo_toggled');
      res.json({
        message: `Promo code ${promo.code} ${nextActive ? 'activated' : 'paused'}.`,
      });
    }
  );

  // Zero-dependency ZIP builder for source download
  const CRC32_TABLE = (() => {
    const table = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let k = 0; k < 8; k++) {
        c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
      }
      table[i] = c >>> 0;
    }
    return table;
  })();

  function computeCrc32(buf: Buffer): number {
    let crc = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
      crc = CRC32_TABLE[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  function buildZipBuffer(files: Array<{ name: string; data: Buffer }>): Buffer {
    const localParts: Buffer[] = [];
    const centralParts: Buffer[] = [];
    let offset = 0;

    for (const file of files) {
      const nameBuf = Buffer.from(file.name.replace(/\\/g, '/'), 'utf8');
      const crc = computeCrc32(file.data);
      const deflated = zlib.deflateRawSync(file.data);
      const useDeflate = deflated.length < file.data.length;
      const payload = useDeflate ? deflated : file.data;
      const method = useDeflate ? 8 : 0;

      const localHeader = Buffer.alloc(30);
      localHeader.writeUInt32LE(0x04034b50, 0);
      localHeader.writeUInt16LE(20, 4);
      localHeader.writeUInt16LE(0x0800, 6);
      localHeader.writeUInt16LE(method, 8);
      localHeader.writeUInt16LE(0, 10);
      localHeader.writeUInt16LE(0x5421, 12);
      localHeader.writeUInt32LE(crc, 14);
      localHeader.writeUInt32LE(payload.length, 18);
      localHeader.writeUInt32LE(file.data.length, 22);
      localHeader.writeUInt16LE(nameBuf.length, 26);
      localHeader.writeUInt16LE(0, 28);

      localParts.push(localHeader, nameBuf, payload);

      const centralHeader = Buffer.alloc(46);
      centralHeader.writeUInt32LE(0x02014b50, 0);
      centralHeader.writeUInt16LE(20, 4);
      centralHeader.writeUInt16LE(20, 6);
      centralHeader.writeUInt16LE(0x0800, 8);
      centralHeader.writeUInt16LE(method, 10);
      centralHeader.writeUInt16LE(0, 12);
      centralHeader.writeUInt16LE(0x5421, 14);
      centralHeader.writeUInt32LE(crc, 16);
      centralHeader.writeUInt32LE(payload.length, 20);
      centralHeader.writeUInt32LE(file.data.length, 24);
      centralHeader.writeUInt16LE(nameBuf.length, 28);
      centralHeader.writeUInt16LE(0, 30);
      centralHeader.writeUInt16LE(0, 32);
      centralHeader.writeUInt16LE(0, 34);
      centralHeader.writeUInt16LE(0, 36);
      centralHeader.writeUInt32LE(0, 38);
      centralHeader.writeUInt32LE(offset, 42);

      centralParts.push(centralHeader, nameBuf);
      offset += localHeader.length + nameBuf.length + payload.length;
    }

    const centralBuf = Buffer.concat(centralParts);
    const eocd = Buffer.alloc(22);
    eocd.writeUInt32LE(0x06054b50, 0);
    eocd.writeUInt16LE(0, 4);
    eocd.writeUInt16LE(0, 6);
    eocd.writeUInt16LE(files.length, 8);
    eocd.writeUInt16LE(files.length, 10);
    eocd.writeUInt32LE(centralBuf.length, 12);
    eocd.writeUInt32LE(offset, 16);
    eocd.writeUInt16LE(0, 20);

    return Buffer.concat([...localParts, centralBuf, eocd]);
  }

  function collectSourceFiles(rootDir: string): Array<{ name: string; data: Buffer }> {
    const rootFiles = [
      'package.json',
      '.env.example',
      '.gitignore',
      'README.md',
      'render.yaml',
      'index.html',
      'metadata.json',
      'tsconfig.json',
      'vite.config.ts',
      'server.ts',
    ];
    const entries: Array<{ name: string; data: Buffer }> = [];

    for (const rel of rootFiles) {
      const fullPath = path.join(rootDir, rel);
      if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
        entries.push({ name: `paisegrow/${rel}`, data: fs.readFileSync(fullPath) });
      }
    }

    const walk = (dirPath: string, relBase: string) => {
      if (!fs.existsSync(dirPath)) return;
      const items = fs.readdirSync(dirPath, { withFileTypes: true });
      for (const item of items) {
        if (item.name.startsWith('Screenshot_')) continue;
        const full = path.join(dirPath, item.name);
        const rel = `${relBase}/${item.name}`;
        if (item.isDirectory()) {
          walk(full, rel);
        } else if (item.isFile()) {
          entries.push({ name: `paisegrow/${rel}`, data: fs.readFileSync(full) });
        }
      }
    };

    walk(path.join(rootDir, 'src'), 'src');
    walk(path.join(rootDir, 'public'), 'public');
    return entries;
  }

  const sendSourceZip = (_req: Request, res: Response) => {
    try {
      const files = collectSourceFiles(process.cwd());
      const zipBuffer = buildZipBuffer(files);
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="paisegrow-source.zip"'
      );
      res.setHeader('Content-Length', String(zipBuffer.length));
      res.send(zipBuffer);
    } catch (err) {
      console.error('Source zip error:', err);
      res.status(500).json({ error: 'Unable to package source code archive.' });
    }
  };

  app.get(
    '/api/admin/download-source',
    requireAuth,
    requireAdmin,
    sendSourceZip
  );

  app.get('/paisegrow-source.zip', sendSourceZip);

  // Vite / Static Asset Handling
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`PaiseGrow server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start PaiseGrow server:', err);
  process.exit(1);
});
