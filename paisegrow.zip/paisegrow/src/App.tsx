import React, { useState, useEffect, useCallback } from 'react';
import {
  Menu,
  X,
  ArrowDownCircle,
  ArrowUpCircle,
  MessageCircle,
  Layers,
  Wallet,
  Users,
  User,
  Shield,
  Ticket,
  LogOut,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import {
  ApiError,
  fetchApi,
  formatRs,
  getApiUrl,
  getStoredToken,
  setStoredToken,
} from './lib/api';
import { WHATSAPP_CHANNEL_URL } from './shared/plans';
import type { DashboardSnapshot } from './types';
import { AuthView } from './components/AuthView';
import { PlansSection } from './components/PlansSection';
import { WalletSection, type WalletTab } from './components/WalletSection';
import { InviteSection } from './components/InviteSection';
import { ProfileSection } from './components/ProfileSection';
import { AdminPanel } from './components/AdminPanel';
import { EarningsChart } from './components/EarningsChart';
import { FaqSection } from './components/FaqSection';

type ActiveSection = 'plans' | 'wallet' | 'invite' | 'faqs' | 'profile' | 'admin';

interface ToastState {
  id: number;
  message: string;
  type: 'success' | 'error';
}

export default function App() {
  const [token, setToken] = useState<string | null>(() => getStoredToken());
  const [snapshot, setSnapshot] = useState<DashboardSnapshot | null>(null);
  const [loading, setLoading] = useState<boolean>(Boolean(getStoredToken()));
  const [activeSection, setActiveSection] = useState<ActiveSection>('plans');
  const [walletTab, setWalletTab] = useState<WalletTab>('deposit');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [toast, setToast] = useState<ToastState | null>(null);
  const [adminRefreshSignal, setAdminRefreshSignal] = useState(0);
  const [logoError, setLogoError] = useState(false);

  const notify = useCallback(
    (message: string, type: 'success' | 'error' = 'success') => {
      const id = Date.now();
      setToast({ id, message, type });
      setTimeout(() => {
        setToast((current) => (current?.id === id ? null : current));
      }, 4500);
    },
    []
  );

  const handleLogout = useCallback(async () => {
    try {
      if (getStoredToken()) {
        await fetchApi('/api/auth/logout', { method: 'POST' });
      }
    } catch {
      // Ignore logout network errors
    } finally {
      setStoredToken(null);
      setToken(null);
      setSnapshot(null);
      setIsMenuOpen(false);
    }
  }, []);

  const loadSnapshot = useCallback(async () => {
    if (!getStoredToken()) {
      setLoading(false);
      return;
    }

    try {
      const data = await fetchApi<DashboardSnapshot>('/api/me');
      setSnapshot(data);
    } catch (err) {
      if (err instanceof ApiError && (err.status === 401 || err.status === 403)) {
        setStoredToken(null);
        setToken(null);
        setSnapshot(null);
        if (err.data.banned) {
          notify('Your account has been suspended by an administrator.', 'error');
        }
      }
    } finally {
      setLoading(false);
    }
  }, [notify]);

  useEffect(() => {
    if (token) {
      setLoading(true);
      loadSnapshot();
    } else {
      setLoading(false);
    }
  }, [token, loadSnapshot]);

  // Real-time Server-Sent Events connection
  useEffect(() => {
    if (!token) return;
    const source = new EventSource(
      getApiUrl(`/api/events?token=${encodeURIComponent(token)}`)
    );

    source.onmessage = (event) => {
      try {
        const parsed = JSON.parse(event.data) as { type?: string };
        if (parsed.type === 'sync') {
          loadSnapshot();
          setAdminRefreshSignal((prev) => prev + 1);
        }
      } catch {
        // Ignore malformed messages
      }
    };

    return () => {
      source.close();
    };
  }, [token, loadSnapshot]);

  const navigateToWallet = (tab: WalletTab) => {
    setWalletTab(tab);
    setActiveSection('wallet');
    setIsMenuOpen(false);
  };

  const navigateToSection = (section: ActiveSection) => {
    setActiveSection(section);
    setIsMenuOpen(false);
  };

  if (!token) {
    return (
      <AuthView
        onAuthenticated={(newToken) => {
          setToken(newToken);
          setActiveSection('plans');
        }}
      />
    );
  }

  if (loading || !snapshot) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-900 flex items-center justify-center p-6">
        <div className="text-sm font-medium text-slate-500">
          Loading your PaiseGrow workspace...
        </div>
      </div>
    );
  }

  const { user } = snapshot;
  const isAdmin = user.role === 'admin';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-20 md:pb-8">
      {/* Top Navigation Header */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 lg:px-8 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Three-Line Menu Button + PaiseGrow Brand Logo */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setIsMenuOpen(true)}
              aria-label="Open menu"
              className="p-2 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>

            <button
              type="button"
              onClick={() => navigateToSection('plans')}
              className="flex items-center gap-2.5 text-left whitespace-nowrap shrink-0 cursor-pointer"
            >
              {!logoError ? (
                <img
                  src="/assets/aistudio/PaiseGrow_Financial_Growth_Logo_ee793b22.png"
                  alt="PaiseGrow"
                  referrerPolicy="no-referrer"
                  onError={() => setLogoError(true)}
                  className="h-9 w-auto object-contain rounded"
                />
              ) : (
                <span className="text-lg font-display font-bold tracking-tight text-slate-900">
                  PaiseGrow
                </span>
              )}
            </button>
          </div>

          {/* Zone 2: Clean Single-Line Nav Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            <button
              type="button"
              onClick={() => navigateToSection('plans')}
              className={`py-1 whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                activeSection === 'plans'
                  ? 'text-emerald-600 underline underline-offset-8'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Plans
            </button>
            <button
              type="button"
              onClick={() => navigateToWallet('deposit')}
              className={`py-1 whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                activeSection === 'wallet'
                  ? 'text-emerald-600 underline underline-offset-8'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Wallet
            </button>
            <button
              type="button"
              onClick={() => navigateToSection('invite')}
              className={`py-1 whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                activeSection === 'invite'
                  ? 'text-emerald-600 underline underline-offset-8'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Invite
            </button>
            <button
              type="button"
              onClick={() => navigateToSection('faqs')}
              className={`py-1 whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                activeSection === 'faqs'
                  ? 'text-emerald-600 underline underline-offset-8'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              FAQs
            </button>
            <button
              type="button"
              onClick={() => navigateToSection('profile')}
              className={`py-1 whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                activeSection === 'profile'
                  ? 'text-emerald-600 underline underline-offset-8'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Profile
            </button>
            {isAdmin && (
              <button
                type="button"
                onClick={() => navigateToSection('admin')}
                className={`py-1 whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  activeSection === 'admin'
                    ? 'text-amber-600 underline underline-offset-8'
                    : 'text-amber-600/80 hover:text-amber-700'
                }`}
              >
                Admin Panel
              </button>
            )}
          </nav>

          {/* Zone 3: Single Primary Action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => navigateToWallet('deposit')}
              className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs font-mono tabular-nums whitespace-nowrap shrink-0 transition-colors cursor-pointer shadow-xs"
            >
              {formatRs(user.balance)} · Deposit
            </button>
          </div>
        </div>
      </header>

      {/* Three-Line Slide-Out Menu Drawer */}
      {isMenuOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex"
          onClick={() => setIsMenuOpen(false)}
        >
          <aside
            className="w-80 max-w-[85vw] h-full bg-white border-r border-slate-200 p-6 flex flex-col justify-between overflow-y-auto shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-slate-200 pb-4">
                <div>
                  <div className="text-base font-display font-bold text-slate-900">
                    {user.name}
                  </div>
                  <div className="text-xs text-slate-500 truncate max-w-[200px]">
                    {user.email}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsMenuOpen(false)}
                  aria-label="Close menu"
                  className="p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200">
                <div className="text-xs text-emerald-700 font-medium">Wallet Balance</div>
                <div className="text-xl font-mono font-bold text-emerald-700 tabular-nums mt-0.5">
                  {formatRs(user.balance)}
                </div>
              </div>

              <div className="space-y-1">
                <div className="px-3 pb-1 text-xs font-medium text-slate-400">
                  Wallet &amp; Channels
                </div>

                <button
                  type="button"
                  onClick={() => navigateToWallet('deposit')}
                  className="w-full px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-100 flex items-center gap-3 cursor-pointer"
                >
                  <ArrowDownCircle className="w-4 h-4 text-emerald-600" />
                  Deposit
                </button>

                <button
                  type="button"
                  onClick={() => navigateToWallet('withdraw')}
                  className="w-full px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-100 flex items-center gap-3 cursor-pointer"
                >
                  <ArrowUpCircle className="w-4 h-4 text-sky-600" />
                  Withdraw
                </button>

                <button
                  type="button"
                  onClick={() => navigateToWallet('promo')}
                  className="w-full px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-100 flex items-center gap-3 cursor-pointer"
                >
                  <Ticket className="w-4 h-4 text-amber-600" />
                  Promo Code
                </button>

                <a
                  href={WHATSAPP_CHANNEL_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full px-3 py-2.5 rounded-lg text-sm font-medium text-emerald-700 hover:bg-emerald-50 flex items-center gap-3"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-600" />
                  WhatsApp Channel
                </a>
              </div>

              <div className="space-y-1 pt-2 border-t border-slate-200">
                <div className="px-3 pb-1 text-xs font-medium text-slate-400">
                  Navigation
                </div>

                <button
                  type="button"
                  onClick={() => navigateToSection('plans')}
                  className="w-full px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-100 flex items-center gap-3 cursor-pointer"
                >
                  <Layers className="w-4 h-4 text-slate-500" />
                  Investment Plans
                </button>

                <button
                  type="button"
                  onClick={() => navigateToSection('invite')}
                  className="w-full px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-100 flex items-center gap-3 cursor-pointer"
                >
                  <Users className="w-4 h-4 text-slate-500" />
                  Invite &amp; Referrals
                </button>

                <button
                  type="button"
                  onClick={() => navigateToSection('faqs')}
                  className="w-full px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-100 flex items-center gap-3 cursor-pointer"
                >
                  <HelpCircle className="w-4 h-4 text-slate-500" />
                  FAQs &amp; Mission
                </button>

                <button
                  type="button"
                  onClick={() => navigateToSection('profile')}
                  className="w-full px-3 py-2.5 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-100 flex items-center gap-3 cursor-pointer"
                >
                  <User className="w-4 h-4 text-slate-500" />
                  Profile
                </button>

                {isAdmin && (
                  <button
                    type="button"
                    onClick={() => navigateToSection('admin')}
                    className="w-full px-3 py-2.5 rounded-lg text-sm font-medium text-amber-700 hover:bg-amber-50 flex items-center gap-3 cursor-pointer"
                  >
                    <Shield className="w-4 h-4 text-amber-600" />
                    Admin Panel
                  </button>
                )}
              </div>
            </div>

            <button
              type="button"
              onClick={handleLogout}
              className="mt-6 w-full px-3 py-2.5 rounded-lg border border-red-200 text-sm font-medium text-red-600 hover:bg-red-50 flex items-center justify-center gap-2 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </button>
          </aside>
        </div>
      )}

      {/* Main Content Container */}
      <main className="max-w-7xl mx-auto px-4 lg:px-8 py-6 lg:py-8 space-y-6">
        {/* Top Real-Time Account Summary Strip */}
        <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="text-xs text-slate-500">Wallet Balance</div>
            <div className="mt-1 text-xl font-mono font-bold text-emerald-600 tabular-nums">
              {formatRs(user.balance)}
            </div>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="text-xs text-slate-500">Plan Earnings</div>
            <div className="mt-1 text-xl font-mono font-bold text-slate-900 tabular-nums">
              {formatRs(user.totalEarned)}
            </div>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="text-xs text-slate-500">Referral Earnings (10%)</div>
            <div className="mt-1 text-xl font-mono font-bold text-amber-600 tabular-nums">
              {formatRs(user.totalReferralEarnings)}
            </div>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="text-xs text-slate-500">Invite Code · Invited</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-xl font-mono font-bold text-slate-900">
                {user.inviteCode}
              </span>
              <span className="text-xs font-mono text-slate-500 tabular-nums">
                ({snapshot.invitedUsers.length})
              </span>
            </div>
          </div>
        </section>

        {activeSection === 'plans' && (
          <>
            <EarningsChart
              activePlans={snapshot.activePlans}
              totalEarned={user.totalEarned}
            />
            <PlansSection
              balance={user.balance}
              activePlans={snapshot.activePlans}
              onPlanPurchased={loadSnapshot}
              onOpenDeposit={() => navigateToWallet('deposit')}
              onNotify={notify}
            />
          </>
        )}

        {activeSection === 'wallet' && (
          <WalletSection
            initialTab={walletTab}
            balance={user.balance}
            deposits={snapshot.deposits}
            withdrawals={snapshot.withdrawals}
            promoRedemptions={snapshot.promoRedemptions}
            onRefresh={loadSnapshot}
            onNotify={notify}
          />
        )}

        {activeSection === 'invite' && (
          <InviteSection
            inviteCode={user.inviteCode}
            totalReferralEarnings={user.totalReferralEarnings}
            invitedUsers={snapshot.invitedUsers}
            commissions={snapshot.commissions}
            onNotify={notify}
          />
        )}

        {activeSection === 'faqs' && <FaqSection />}

        {activeSection === 'profile' && (
          <ProfileSection
            user={user}
            onRefresh={loadSnapshot}
            onNotify={notify}
          />
        )}

        {activeSection === 'admin' && isAdmin && (
          <AdminPanel
            refreshSignal={adminRefreshSignal}
            onGlobalRefresh={loadSnapshot}
            onNotify={notify}
          />
        )}
      </main>

      {/* Bottom Quick Navigation Bar (Mobile & Compact Viewports) */}
      <nav
        aria-label="Bottom Navigation"
        className="md:hidden fixed bottom-0 inset-x-0 z-30 h-14 bg-white/95 backdrop-blur border-t border-slate-200 flex items-center justify-around px-2"
      >
        <button
          type="button"
          onClick={() => navigateToSection('plans')}
          className={`flex flex-col items-center justify-center gap-0.5 px-3 py-1 text-[11px] font-medium cursor-pointer ${
            activeSection === 'plans' ? 'text-emerald-600' : 'text-slate-500'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Plans</span>
        </button>

        <button
          type="button"
          onClick={() => navigateToWallet('deposit')}
          className={`flex flex-col items-center justify-center gap-0.5 px-3 py-1 text-[11px] font-medium cursor-pointer ${
            activeSection === 'wallet' ? 'text-emerald-600' : 'text-slate-500'
          }`}
        >
          <Wallet className="w-4 h-4" />
          <span>Wallet</span>
        </button>

        <button
          type="button"
          onClick={() => navigateToSection('invite')}
          className={`flex flex-col items-center justify-center gap-0.5 px-3 py-1 text-[11px] font-medium cursor-pointer ${
            activeSection === 'invite' ? 'text-emerald-600' : 'text-slate-500'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Invite</span>
        </button>

        <button
          type="button"
          onClick={() => navigateToSection('faqs')}
          className={`flex flex-col items-center justify-center gap-0.5 px-3 py-1 text-[11px] font-medium cursor-pointer ${
            activeSection === 'faqs' ? 'text-emerald-600' : 'text-slate-500'
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>FAQs</span>
        </button>

        <button
          type="button"
          onClick={() => navigateToSection('profile')}
          className={`flex flex-col items-center justify-center gap-0.5 px-3 py-1 text-[11px] font-medium cursor-pointer ${
            activeSection === 'profile' ? 'text-emerald-600' : 'text-slate-500'
          }`}
        >
          <User className="w-4 h-4" />
          <span>Profile</span>
        </button>

        {isAdmin && (
          <button
            type="button"
            onClick={() => navigateToSection('admin')}
            className={`flex flex-col items-center justify-center gap-0.5 px-3 py-1 text-[11px] font-medium cursor-pointer ${
              activeSection === 'admin' ? 'text-amber-600' : 'text-slate-500'
            }`}
          >
            <Shield className="w-4 h-4" />
            <span>Admin</span>
          </button>
        )}
      </nav>

      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-20 md:bottom-6 right-4 lg:right-8 z-50 max-w-sm rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-lg flex items-start gap-3">
          {toast.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
          )}
          <div className="text-xs text-slate-800 leading-relaxed flex-1">
            {toast.message}
          </div>
          <button
            type="button"
            onClick={() => setToast(null)}
            className="text-slate-400 hover:text-slate-700 cursor-pointer"
            aria-label="Dismiss notification"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}
