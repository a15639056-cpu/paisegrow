import React, { useState, useEffect, useCallback } from 'react';
import {
  Users,
  ArrowDownCircle,
  ArrowUpCircle,
  Ticket,
  Ban,
  CheckCircle2,
  XCircle,
  Search,
  Sparkles,
  Download,
  X,
} from 'lucide-react';
import {
  fetchApi,
  formatDateTime,
  formatRs,
  getApiUrl,
  getStoredToken,
} from '../lib/api';
import type { AdminOverviewData } from '../types';

interface AdminPanelProps {
  refreshSignal: number;
  onGlobalRefresh: () => Promise<void>;
  onNotify: (message: string, type?: 'success' | 'error') => void;
}

type AdminTab = 'users' | 'deposits' | 'withdrawals' | 'promos';
type UserFilter = 'all' | 'buyers' | 'non_buyers' | 'banned';

export const AdminPanel: React.FC<AdminPanelProps> = ({
  refreshSignal,
  onGlobalRefresh,
  onNotify,
}) => {
  const [data, setData] = useState<AdminOverviewData | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<AdminTab>('users');
  const [userFilter, setUserFilter] = useState<UserFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [downloadingSource, setDownloadingSource] = useState(false);

  // Promo generator state
  const [promoCode, setPromoCode] = useState('');
  const [promoReward, setPromoReward] = useState('50');
  const [promoMaxUses, setPromoMaxUses] = useState('25');
  const [promoExpiry, setPromoExpiry] = useState(() => {
    const dt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    return dt.toISOString().slice(0, 16);
  });
  const [creatingPromo, setCreatingPromo] = useState(false);

  const loadAdminOverview = useCallback(async () => {
    try {
      const overview = await fetchApi<AdminOverviewData>('/api/admin/overview');
      setData(overview);
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'Unable to load admin overview.',
        'error'
      );
    } finally {
      setLoading(false);
    }
  }, [onNotify]);

  useEffect(() => {
    loadAdminOverview();
  }, [loadAdminOverview, refreshSignal]);

  const handleDownloadSource = async () => {
    setDownloadingSource(true);
    try {
      const token = getStoredToken();
      const response = await fetch(getApiUrl('/api/admin/download-source'), {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (!response.ok) {
        const errData = (await response.json().catch(() => ({}))) as {
          error?: string;
        };
        throw new Error(errData.error || 'Unable to download source code archive.');
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'paisegrow-source.zip';
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      onNotify('PaiseGrow source archive (paisegrow-source.zip) downloaded.', 'success');
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'Unable to download source archive.',
        'error'
      );
    } finally {
      setDownloadingSource(false);
    }
  };

  const handleToggleBan = async (userId: string) => {
    try {
      const res = await fetchApi<{ message: string }>(
        `/api/admin/users/${userId}/ban`,
        { method: 'POST' }
      );
      onNotify(res.message, 'success');
      await loadAdminOverview();
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'Unable to update user status.',
        'error'
      );
    }
  };

  const handleReviewDeposit = async (
    depositId: string,
    action: 'approve' | 'reject'
  ) => {
    try {
      const res = await fetchApi<{ message: string }>(
        `/api/admin/deposits/${depositId}/review`,
        {
          method: 'POST',
          body: JSON.stringify({ action }),
        }
      );
      onNotify(res.message, 'success');
      await loadAdminOverview();
      await onGlobalRefresh();
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'Unable to review deposit.',
        'error'
      );
    }
  };

  const handleReviewWithdrawal = async (
    withdrawalId: string,
    action: 'approve' | 'reject'
  ) => {
    try {
      const res = await fetchApi<{ message: string }>(
        `/api/admin/withdrawals/${withdrawalId}/review`,
        {
          method: 'POST',
          body: JSON.stringify({ action }),
        }
      );
      onNotify(res.message, 'success');
      await loadAdminOverview();
      await onGlobalRefresh();
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'Unable to review withdrawal.',
        'error'
      );
    }
  };

  const handleGenerateRandomCode = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = 'PG';
    for (let i = 0; i < 6; i++) {
      code += chars[Math.floor(Math.random() * chars.length)];
    }
    setPromoCode(code);
  };

  const handleCreatePromo = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreatingPromo(true);
    try {
      const res = await fetchApi<{ message: string }>('/api/admin/promos', {
        method: 'POST',
        body: JSON.stringify({
          code: promoCode,
          rewardAmount: Number(promoReward),
          maxUses: Number(promoMaxUses),
          expiresAt: new Date(promoExpiry).toISOString(),
        }),
      });
      onNotify(res.message, 'success');
      setPromoCode('');
      await loadAdminOverview();
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'Unable to create promo code.',
        'error'
      );
    } finally {
      setCreatingPromo(false);
    }
  };

  const handleTogglePromo = async (promoId: string) => {
    try {
      const res = await fetchApi<{ message: string }>(
        `/api/admin/promos/${promoId}`,
        { method: 'PATCH' }
      );
      onNotify(res.message, 'success');
      await loadAdminOverview();
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'Unable to toggle promo code.',
        'error'
      );
    }
  };

  if (loading || !data) {
    return (
      <div className="p-8 rounded-xl border border-slate-200 bg-white text-sm text-slate-500 shadow-sm">
        Loading real-time admin overview...
      </div>
    );
  }

  const filteredUsers = data.users.filter((u) => {
    if (userFilter === 'buyers' && u.total_plans_count === 0) return false;
    if (userFilter === 'non_buyers' && u.total_plans_count > 0) return false;
    if (userFilter === 'banned' && !u.is_banned) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        u.name.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        u.invite_code.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <h1 className="text-2xl font-display font-bold text-slate-900">
            Admin Control Panel
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Real-time user management, deposit approvals, withdrawal payouts, and promo code generator.
          </p>
        </div>

        <button
          type="button"
          disabled={downloadingSource}
          onClick={handleDownloadSource}
          className="px-4 py-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-semibold text-xs inline-flex items-center gap-2 whitespace-nowrap w-fit cursor-pointer shadow-sm"
        >
          <Download className="w-4 h-4" />
          {downloadingSource ? 'Packaging ZIP...' : 'Download Source (.zip)'}
        </button>
      </div>

      {/* Real-Time KPI Summary Row */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="text-xs text-slate-500">Total Users</div>
          <div className="mt-1.5 text-2xl font-mono font-bold text-slate-900 tabular-nums">
            {data.stats.totalUsers}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="text-xs text-slate-500">Bought Plans</div>
          <div className="mt-1.5 text-2xl font-mono font-bold text-emerald-600 tabular-nums">
            {data.stats.buyersCount}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="text-xs text-slate-500">No Plan Yet</div>
          <div className="mt-1.5 text-2xl font-mono font-bold text-slate-700 tabular-nums">
            {data.stats.nonBuyersCount}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="text-xs text-slate-500">Pending Deposits</div>
          <div className="mt-1.5 text-2xl font-mono font-bold text-amber-600 tabular-nums">
            {data.stats.pendingDeposits}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="text-xs text-slate-500">Pending Withdrawals</div>
          <div className="mt-1.5 text-2xl font-mono font-bold text-sky-600 tabular-nums">
            {data.stats.pendingWithdrawals}
          </div>
        </div>
      </div>

      {/* Section Tabs */}
      <div className="flex flex-wrap items-center gap-1 p-1 rounded-lg bg-slate-100 border border-slate-200 w-fit">
        <button
          type="button"
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2 rounded-md text-xs font-medium flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'users'
              ? 'bg-emerald-600 text-white font-semibold shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Users className="w-4 h-4" />
          Users ({data.stats.totalUsers})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('deposits')}
          className={`px-4 py-2 rounded-md text-xs font-medium flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'deposits'
              ? 'bg-emerald-600 text-white font-semibold shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <ArrowDownCircle className="w-4 h-4" />
          Deposits ({data.deposits.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('withdrawals')}
          className={`px-4 py-2 rounded-md text-xs font-medium flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'withdrawals'
              ? 'bg-emerald-600 text-white font-semibold shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <ArrowUpCircle className="w-4 h-4" />
          Withdrawals ({data.withdrawals.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('promos')}
          className={`px-4 py-2 rounded-md text-xs font-medium flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'promos'
              ? 'bg-emerald-600 text-white font-semibold shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Ticket className="w-4 h-4" />
          Promo Codes ({data.promoCodes.length})
        </button>
      </div>

      {/* USERS TAB */}
      {activeTab === 'users' && (
        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-sm">
          <div className="p-4 border-b border-slate-200 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-1 p-1 rounded-lg bg-slate-100 border border-slate-200 w-fit">
              {(
                [
                  { key: 'all', label: `All (${data.stats.totalUsers})` },
                  { key: 'buyers', label: `Bought Plan (${data.stats.buyersCount})` },
                  {
                    key: 'non_buyers',
                    label: `No Plan Yet (${data.stats.nonBuyersCount})`,
                  },
                  { key: 'banned', label: `Banned (${data.stats.bannedCount})` },
                ] as const
              ).map((item) => (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => setUserFilter(item.key)}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap cursor-pointer ${
                    userFilter === item.key
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <div className="relative w-full lg:w-72">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search name, email, or code..."
                className="w-full pl-9 pr-3 py-2 rounded-lg bg-slate-50 border border-slate-300 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-600"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-xs text-slate-500 bg-slate-50">
                  <th className="py-3 px-5 font-medium">User</th>
                  <th className="py-3 px-4 font-medium">Plan Category</th>
                  <th className="py-3 px-4 font-medium text-right">Balance</th>
                  <th className="py-3 px-4 font-medium text-right">Invested</th>
                  <th className="py-3 px-4 font-medium text-right">Invited</th>
                  <th className="py-3 px-4 font-medium">Status</th>
                  <th className="py-3 px-5 font-medium text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredUsers.map((usr) => (
                  <tr key={usr.id} className="hover:bg-slate-50">
                    <td className="py-3.5 px-5">
                      <div className="font-semibold text-slate-900 text-xs">
                        {usr.name}
                        {usr.role === 'admin' && (
                          <span className="ml-2 text-emerald-600 font-mono">
                            (Admin)
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-500">
                        {usr.email} · <span className="font-mono">{usr.invite_code}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-xs">
                      {usr.total_plans_count > 0 ? (
                        <span className="text-emerald-600 font-medium">
                          Buyer ({usr.total_plans_count}{' '}
                          {usr.total_plans_count === 1 ? 'plan' : 'plans'})
                        </span>
                      ) : (
                        <span className="text-slate-500">No Plan Purchased</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono tabular-nums text-slate-900">
                      {formatRs(usr.balance)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono tabular-nums text-slate-700">
                      {formatRs(usr.total_invested)}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono tabular-nums text-slate-700">
                      {usr.invited_count}
                    </td>
                    <td className="py-3.5 px-4 text-xs font-medium">
                      {usr.is_banned ? (
                        <span className="text-red-600">Banned</span>
                      ) : (
                        <span className="text-emerald-600">Active</span>
                      )}
                    </td>
                    <td className="py-3.5 px-5 text-right">
                      {usr.role !== 'admin' ? (
                        <button
                          type="button"
                          onClick={() => handleToggleBan(usr.id)}
                          className={`px-3 py-1.5 rounded-md text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer ${
                            usr.is_banned
                              ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
                              : 'bg-red-50 text-red-700 hover:bg-red-100 border border-red-200'
                          }`}
                        >
                          <Ban className="w-3.5 h-3.5" />
                          {usr.is_banned ? 'Unban' : 'Ban User'}
                        </button>
                      ) : (
                        <span className="text-xs text-slate-400">Protected</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* DEPOSITS TAB */}
      {activeTab === 'deposits' && (
        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-sm">
          <div className="px-6 py-4 border-b border-slate-200">
            <h2 className="text-base font-display font-semibold text-slate-900">
              Deposit Requests Queue
            </h2>
          </div>
          {data.deposits.length === 0 ? (
            <div className="p-6 text-xs text-slate-500">No deposits submitted yet.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-xs text-slate-500 bg-slate-50">
                    <th className="py-3 px-5 font-medium">User</th>
                    <th className="py-3 px-4 font-medium text-right">Amount</th>
                    <th className="py-3 px-4 font-medium">Reference</th>
                    <th className="py-3 px-4 font-medium">Screenshot</th>
                    <th className="py-3 px-4 font-medium">Status</th>
                    <th className="py-3 px-4 font-medium">Submitted</th>
                    <th className="py-3 px-5 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {data.deposits.map((dep) => (
                    <tr key={dep.id}>
                      <td className="py-3.5 px-5">
                        <div className="text-xs font-semibold text-slate-900">
                          {dep.user_name}
                        </div>
                        <div className="text-xs text-slate-500">{dep.user_email}</div>
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                        {formatRs(dep.amount)}
                      </td>
                      <td className="py-3.5 px-4 text-xs font-mono text-slate-700">
                        {dep.transaction_ref || '—'}
                      </td>
                      <td className="py-3.5 px-4">
                        <button
                          type="button"
                          onClick={() => setPreviewImage(getApiUrl(dep.screenshot_path))}
                          className="text-xs font-medium text-sky-600 hover:underline cursor-pointer"
                        >
                          View Receipt
                        </button>
                      </td>
                      <td className="py-3.5 px-4 text-xs font-medium capitalize">
                        <span
                          className={
                            dep.status === 'approved'
                              ? 'text-emerald-600'
                              : dep.status === 'rejected'
                              ? 'text-red-600'
                              : 'text-amber-600'
                          }
                        >
                          {dep.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-xs font-mono text-slate-500 tabular-nums">
                        {formatDateTime(dep.created_at)}
                      </td>
                      <td className="py-3.5 px-5 text-right">
                        {dep.status === 'pending' ? (
                          <div className="inline-flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => handleReviewDeposit(dep.id, 'approve')}
                              className="px-2.5 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs inline-flex items-center gap-1 cursor-pointer"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              Approve
                            </button>
                            <button
                              type="button"
                              onClick={() => handleReviewDeposit(dep.id, 'reject')}
                              className="px-2.5 py-1.5 rounded bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 font-semibold text-xs inline-flex items-center gap-1 cursor-pointer"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              Reject
                            </button>
                          </div>
                        ) : (
                          <span className="text-xs text-slate-400">Reviewed</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* WITHDRAWALS TAB */}
      {activeTab === 'withdrawals' && (
        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-sm">
          <div className="px-6 py-4 border-b border-slate-200">
            <h2 className="text-base font-display font-semibold text-slate-900">
              Withdrawal Requests Queue
            </h2>
          </div>
          {data.withdrawals.length === 0 ? (
            <div className="p-6 text-xs text-slate-500">
              No withdrawal requests yet.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-xs text-slate-500 bg-slate-50">
                    <th className="py-3 px-5 font-medium">User</th>
                    <th className="py-3 px-4 font-medium">Bank / Account</th>
                    <th className="py-3 px-4 font-medium text-right">Amount</th>
                    <th className="py-3 px-4 font-medium">Status</th>
                    <th className="py-3 px-4 font-medium">Requested</th>
                    <th className="py-3 px-5 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {data.withdrawals.map((wd) => (
                    <tr key={wd.id}>
                      <td className="py-3.5 px-5">
                        <div className="text-xs font-semibold text-slate-900">
                          {wd.user_name}
                        </div>
                        <div className="text-xs text-slate-500">{wd.user_email}</div>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="text-xs font-semibold text-emerald-600">
                          {wd.bank_name}
                        </div>
                        <div className="text-xs font-mono text-slate-700">
                          {wd.account_name} · {wd.account_number}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                        {formatRs(wd.amount)}
                      </td>
                      <td className="py-3.5 px-4 text-xs font-medium capitalize">
                        <span
                          className={
                            wd.status === 'approved'
                              ? 'text-emerald-600'
                              : wd.status === 'rejected'
                              ? 'text-red-600'
                              : 'text-amber-600'
                          }
                        >
                          {wd.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-xs font-mono text-slate-500 tabular-nums">
                        {formatDateTime(wd.created_at)}
                      </td>
                      <td className="py-3.5 px-5 text-right">
                        {wd.status === 'pending' ? (
                          <div className="inline-flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => handleReviewWithdrawal(wd.id, 'approve')}
                              className="px-2.5 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs inline-flex items-center gap-1 cursor-pointer"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              Approve
                            </button>
                            <button
                              type="button"
                              onClick={() => handleReviewWithdrawal(wd.id, 'reject')}
                              className="px-2.5 py-1.5 rounded bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 font-semibold text-xs inline-flex items-center gap-1 cursor-pointer"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              Reject &amp; Refund
                            </button>
                          </div>
                        ) : (
                          <span className="text-xs text-slate-400">Reviewed</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* PROMO CODES TAB */}
      {activeTab === 'promos' && (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          <form
            onSubmit={handleCreatePromo}
            className="xl:col-span-4 rounded-xl border border-slate-200 bg-white p-6 space-y-4 shadow-sm"
          >
            <h2 className="text-base font-display font-semibold text-slate-900">
              Generate Promo Code
            </h2>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-medium text-slate-700">
                  Promo Code
                </label>
                <button
                  type="button"
                  onClick={handleGenerateRandomCode}
                  className="text-xs text-emerald-600 hover:text-emerald-500 flex items-center gap-1 cursor-pointer font-medium"
                >
                  <Sparkles className="w-3 h-3" />
                  Auto-Generate
                </button>
              </div>
              <input
                type="text"
                required
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                placeholder="e.g. BONUS100"
                className="w-full px-3.5 py-2 rounded-lg bg-slate-50 border border-slate-300 text-sm font-mono uppercase text-slate-900 focus:outline-none focus:border-emerald-600"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Reward Amount (Rs.)
                </label>
                <input
                  type="number"
                  min={1}
                  required
                  value={promoReward}
                  onChange={(e) => setPromoReward(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-50 border border-slate-300 text-sm font-mono text-slate-900 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Max Usage Limit
                </label>
                <input
                  type="number"
                  min={1}
                  required
                  value={promoMaxUses}
                  onChange={(e) => setPromoMaxUses(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-50 border border-slate-300 text-sm font-mono text-slate-900 focus:outline-none focus:border-emerald-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Expiry Date &amp; Time
              </label>
              <input
                type="datetime-local"
                required
                value={promoExpiry}
                onChange={(e) => setPromoExpiry(e.target.value)}
                className="w-full px-3.5 py-2 rounded-lg bg-slate-50 border border-slate-300 text-sm font-mono text-slate-900 focus:outline-none focus:border-emerald-600"
              />
            </div>

            <button
              type="submit"
              disabled={creatingPromo}
              className="w-full py-2.5 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-sm cursor-pointer"
            >
              {creatingPromo ? 'Creating...' : 'Create Promo Code'}
            </button>
          </form>

          <div className="xl:col-span-8 rounded-xl border border-slate-200 bg-white overflow-hidden shadow-sm">
            <div className="px-6 py-4 border-b border-slate-200">
              <h2 className="text-base font-display font-semibold text-slate-900">
                Active &amp; Past Promo Codes
              </h2>
            </div>
            {data.promoCodes.length === 0 ? (
              <div className="p-6 text-xs text-slate-500">
                No promo codes created yet.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 text-xs text-slate-500 bg-slate-50">
                      <th className="py-3 px-5 font-medium">Code</th>
                      <th className="py-3 px-4 font-medium text-right">Reward</th>
                      <th className="py-3 px-4 font-medium text-right">Uses</th>
                      <th className="py-3 px-4 font-medium">Expires At</th>
                      <th className="py-3 px-4 font-medium">State</th>
                      <th className="py-3 px-5 font-medium text-right">Control</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {data.promoCodes.map((pc) => {
                      const isExpired =
                        new Date(pc.expires_at).getTime() < Date.now();
                      return (
                        <tr key={pc.id}>
                          <td className="py-3 px-5 font-mono font-bold text-slate-900">
                            {pc.code}
                          </td>
                          <td className="py-3 px-4 text-right font-mono text-emerald-600 tabular-nums">
                            {formatRs(pc.reward_amount)}
                          </td>
                          <td className="py-3 px-4 text-right font-mono text-slate-700 tabular-nums">
                            {pc.used_count} / {pc.max_uses}
                          </td>
                          <td className="py-3 px-4 text-xs font-mono text-slate-500 tabular-nums">
                            {formatDateTime(pc.expires_at)}
                          </td>
                          <td className="py-3 px-4 text-xs font-medium">
                            {isExpired ? (
                              <span className="text-slate-400">Expired</span>
                            ) : pc.is_active ? (
                              <span className="text-emerald-600">Active</span>
                            ) : (
                              <span className="text-amber-600">Paused</span>
                            )}
                          </td>
                          <td className="py-3 px-5 text-right">
                            <button
                              type="button"
                              onClick={() => handleTogglePromo(pc.id)}
                              className="px-3 py-1 rounded bg-slate-100 hover:bg-slate-200 border border-slate-300 text-xs text-slate-800 cursor-pointer"
                            >
                              {pc.is_active ? 'Pause' : 'Activate'}
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Receipt Image Modal */}
      {previewImage && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setPreviewImage(null)}
        >
          <div
            className="relative max-w-2xl w-full rounded-xl border border-slate-200 bg-white p-4 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-semibold text-slate-900">
                Payment Receipt Screenshot
              </span>
              <button
                type="button"
                onClick={() => setPreviewImage(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
                aria-label="Close receipt preview"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <img
              src={previewImage}
              alt="Deposit payment receipt"
              className="w-full max-h-[75vh] object-contain rounded-lg bg-slate-100"
            />
          </div>
        </div>
      )}
    </div>
  );
};
