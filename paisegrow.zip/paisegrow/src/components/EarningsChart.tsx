import React, { useMemo } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import { TrendingUp } from 'lucide-react';
import type { UserPlanSubscription } from '../types';
import { formatRs } from '../lib/api';

interface EarningsChartProps {
  activePlans: UserPlanSubscription[];
  totalEarned: number;
}

interface DailyPoint {
  label: string;
  fullDate: string;
  daily: number;
  cumulative: number;
}

export const EarningsChart: React.FC<EarningsChartProps> = ({
  activePlans,
  totalEarned,
}) => {
  const { chartData, currentDailyRate } = useMemo(() => {
    const today = new Date();
    today.setHours(23, 59, 59, 999);

    const days: {
      key: string;
      label: string;
      fullDate: string;
      startMs: number;
      endMs: number;
    }[] = [];
    for (let offset = 6; offset >= 0; offset--) {
      const d = new Date(today);
      d.setDate(today.getDate() - offset);
      const start = new Date(d);
      start.setHours(0, 0, 0, 0);
      const end = new Date(d);
      end.setHours(23, 59, 59, 999);

      const key = `${start.getFullYear()}-${String(start.getMonth() + 1).padStart(2, '0')}-${String(start.getDate()).padStart(2, '0')}`;
      const label = start.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
      });
      const fullDate = start.toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
      });
      days.push({
        key,
        label,
        fullDate,
        startMs: start.getTime(),
        endMs: end.getTime(),
      });
    }

    const dailyMap = new Map<string, number>();
    for (const day of days) {
      dailyMap.set(day.key, 0);
    }

    let priorEarnedBeforeWindow = 0;
    const windowStartMs = days[0].startMs;

    for (const plan of activePlans) {
      const purchasedMs = new Date(plan.purchased_at).getTime();
      for (let dayNum = 1; dayNum <= plan.days_credited; dayNum++) {
        const creditMs = purchasedMs + dayNum * 24 * 60 * 60 * 1000;
        if (creditMs < windowStartMs) {
          priorEarnedBeforeWindow += plan.daily_earning;
        } else {
          const creditDate = new Date(creditMs);
          const key = `${creditDate.getFullYear()}-${String(creditDate.getMonth() + 1).padStart(2, '0')}-${String(creditDate.getDate()).padStart(2, '0')}`;
          if (dailyMap.has(key)) {
            dailyMap.set(key, (dailyMap.get(key) || 0) + plan.daily_earning);
          }
        }
      }
    }

    let runningTotal = priorEarnedBeforeWindow;
    const points: DailyPoint[] = days.map((day) => {
      const daily = dailyMap.get(day.key) || 0;
      runningTotal += daily;
      return {
        label: day.label,
        fullDate: day.fullDate,
        daily,
        cumulative: runningTotal,
      };
    });

    const activeDailyRate = activePlans
      .filter((p) => p.status === 'active')
      .reduce((sum, p) => sum + p.daily_earning, 0);

    return {
      chartData: points,
      currentDailyRate: activeDailyRate,
    };
  }, [activePlans]);

  return (
    <section className="rounded-xl border border-slate-200 bg-white p-5 lg:p-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
        <div>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-600" />
            <h2 className="text-base font-display font-semibold text-slate-900">
              7-Day Investment Earnings Growth
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Cumulative and daily plan returns over the last 7 days
          </p>
        </div>

        <div className="flex items-center gap-6 text-xs">
          <div>
            <span className="text-slate-500">Active Daily Rate</span>
            <div className="font-mono font-semibold text-emerald-600 tabular-nums mt-0.5">
              +{formatRs(currentDailyRate)} / day
            </div>
          </div>
          <div className="border-l border-slate-200 pl-6">
            <span className="text-slate-500">Total Plan Earnings</span>
            <div className="font-mono font-semibold text-slate-900 tabular-nums mt-0.5">
              {formatRs(totalEarned)}
            </div>
          </div>
        </div>
      </div>

      <div className="h-56 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart
            data={chartData}
            margin={{ top: 8, right: 12, left: -8, bottom: 0 }}
          >
            <CartesianGrid
              stroke="#e2e8f0"
              strokeDasharray="3 3"
              vertical={false}
            />
            <XAxis
              dataKey="label"
              stroke="#64748b"
              fontSize={11}
              tickLine={false}
              axisLine={{ stroke: '#e2e8f0' }}
            />
            <YAxis
              stroke="#64748b"
              fontSize={11}
              tickLine={false}
              axisLine={false}
              tickFormatter={(val: number) => `Rs.${val}`}
            />
            <Tooltip
              content={({ active, payload }) => {
                if (!active || !payload || payload.length === 0) return null;
                const item = payload[0].payload as DailyPoint;
                return (
                  <div className="rounded-lg border border-slate-200 bg-white px-3.5 py-2.5 text-xs shadow-lg">
                    <div className="font-semibold text-slate-800 mb-1">
                      {item.fullDate}
                    </div>
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-slate-500">Cumulative:</span>
                      <span className="font-mono font-semibold text-emerald-600 tabular-nums">
                        {formatRs(item.cumulative)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between gap-4 mt-0.5">
                      <span className="text-slate-500">Daily Accrued:</span>
                      <span className="font-mono font-semibold text-slate-900 tabular-nums">
                        +{formatRs(item.daily)}
                      </span>
                    </div>
                  </div>
                );
              }}
            />
            <Line
              type="monotone"
              dataKey="cumulative"
              name="Cumulative Earnings"
              stroke="#16a34a"
              strokeWidth={2.5}
              dot={{ r: 3.5, fill: '#16a34a', strokeWidth: 0 }}
              activeDot={{ r: 5, fill: '#10b981', stroke: '#ffffff', strokeWidth: 2 }}
            />
            <Line
              type="monotone"
              dataKey="daily"
              name="Daily Earnings"
              stroke="#d97706"
              strokeWidth={2}
              dot={{ r: 3, fill: '#d97706', strokeWidth: 0 }}
              activeDot={{ r: 4.5, fill: '#f59e0b', stroke: '#ffffff', strokeWidth: 2 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
};
