import React, { useState } from 'react';
import { ChevronDown, BookOpen, ShieldCheck, Target, Compass } from 'lucide-react';

interface FaqItem {
  question: string;
  answer: string;
}

const FAQ_ITEMS: FaqItem[] = [
  {
    question: 'What is PAISEGROW and who is it built for?',
    answer:
      'PAISEGROW is a learning and earning platform created for the youth of Pakistan. Our mission is simple: Learn First, Earn Second, Grow Forever. We help you understand how money works, how to save it, how to manage it, and how to earn legally through online tasks.',
  },
  {
    question: 'What activities can I do on PAISEGROW?',
    answer:
      'You can grow through Daily Tasks (complete simple daily tasks and collect points), Watch Ads & Earn (watch 15-second ads and get rewarded with points), Invite & Earn (invite your friends with your referral link and get 10% bonus points from their activity), and Financial Learning (learn basic financial discipline, saving habits, and smart earning methods).',
  },
  {
    question: 'Do I need to pay any real money to start?',
    answer:
      'Our Promise: We do not take any real money deposit from anyone. You do not need to invest to start. You just need to work smart, complete your tasks daily, and grow your points. Your points are your earnings — the more consistent you are, the more you grow.',
  },
  {
    question: 'How does the Invite & Earn 10% bonus work?',
    answer:
      'Share your unique invite link or invite code from the Invite tab. Whenever your friends register using your link and participate in platform activities or plans, you receive a 10% referral bonus automatically credited to your account.',
  },
];

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="space-y-8">
      <section className="rounded-xl border border-slate-200 bg-white p-6 lg:p-8 space-y-6">
        <div className="border-b border-slate-200 pb-5">
          <h1 className="text-2xl lg:text-3xl font-display font-bold text-slate-900 tracking-tight">
            Welcome to PAISEGROW — Earn · Grow · Succeed
          </h1>
          <p className="mt-2 text-sm lg:text-base text-emerald-600 font-semibold">
            Learn First, Earn Second, Grow Forever.
          </p>
        </div>

        <div className="space-y-4 text-sm text-slate-600 leading-relaxed max-w-4xl">
          <p>
            PAISEGROW is a learning and earning platform created for the youth of Pakistan. Our mission is simple:{' '}
            <strong className="text-slate-900">
              Learn First, Earn Second, Grow Forever.
            </strong>
          </p>
          <p>
            We believe that financial growth does not come from shortcuts. It comes from discipline, consistency, and smart work. That is why PAISEGROW helps you understand how money works, how to save it, how to manage it, and how to earn legally through online tasks.
          </p>
        </div>

        <div className="pt-2">
          <div className="flex items-center gap-2 mb-4">
            <BookOpen className="w-4 h-4 text-emerald-600" />
            <h2 className="text-base font-display font-semibold text-slate-900">
              What We Do
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
              <div className="text-sm font-semibold text-slate-900">Daily Tasks</div>
              <p className="mt-1 text-xs text-slate-600 leading-relaxed">
                Complete simple daily tasks and collect points.
              </p>
            </div>
            <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
              <div className="text-sm font-semibold text-slate-900">
                Watch Ads &amp; Earn
              </div>
              <p className="mt-1 text-xs text-slate-600 leading-relaxed">
                Watch 15-second ads and get rewarded with points.
              </p>
            </div>
            <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
              <div className="text-sm font-semibold text-slate-900">
                Invite &amp; Earn
              </div>
              <p className="mt-1 text-xs text-slate-600 leading-relaxed">
                Invite your friends with your referral link and get 10% bonus points from their activity.
              </p>
            </div>
            <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
              <div className="text-sm font-semibold text-slate-900">
                Financial Learning
              </div>
              <p className="mt-1 text-xs text-slate-600 leading-relaxed">
                Learn basic financial discipline, saving habits, and smart earning methods.
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-4 border-t border-slate-200">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <h2 className="text-base font-display font-semibold text-slate-900">
                Our Promise
              </h2>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">
              We do not take any real money deposit from anyone. You don&apos;t need to invest to start. You just need to work smart, complete your tasks daily, and grow your points.
            </p>
            <p className="text-sm text-emerald-600 font-semibold">
              Your points are your earnings. The more consistent you are, the more you grow.
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-amber-600" />
              <h2 className="text-base font-display font-semibold text-slate-900">
                Our Vision
              </h2>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">
              To build a community where every young person in Pakistan can learn financial skills, earn with honesty, and build a better future for themselves and their family.
            </p>
            <div className="pt-2 flex flex-wrap items-center gap-3 text-xs font-mono text-slate-500">
              <span className="text-slate-900 font-semibold">
                PAISEGROW - Earn Grow Succeed
              </span>
              <span aria-hidden="true">·</span>
              <span>Financial Discipline + Daily Earning Smart</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-600 font-semibold">Work = Success</span>
            </div>
          </div>
        </div>
      </section>

      <section className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center gap-2">
          <Target className="w-4 h-4 text-emerald-600" />
          <h2 className="text-base font-display font-semibold text-slate-900">
            Frequently Asked Questions
          </h2>
        </div>

        <div className="divide-y divide-slate-200">
          {FAQ_ITEMS.map((item, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div key={item.question}>
                <button
                  type="button"
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  className="w-full px-6 py-4 text-left flex items-center justify-between gap-4 hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  <span className="text-sm font-semibold text-slate-900">
                    {item.question}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-400 shrink-0 transition-transform ${
                      isOpen ? 'rotate-180 text-emerald-600' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-6 pb-4 text-sm text-slate-600 leading-relaxed">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
