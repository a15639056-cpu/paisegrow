import React, { useState } from 'react';
import { Copy, Check, Users, Percent, Award } from 'lucide-react';
import { formatDateTime, formatRs } from '../lib/api';
import type { InvitedUserRecord, ReferralCommissionRecord } from '../types';

interface InviteSectionProps {
  inviteCode: string;
  totalReferralEarnings: number;
  invitedUsers: InvitedUserRecord[];
  commissions: ReferralCommissionRecord[];
  onNotify: (message: string, type?: 'success' | 'error') => void;
}

export const InviteSection: React.FC<InviteSectionProps> = ({
  inviteCode,
  totalReferralEarnings,
  invitedUsers,
  commissions,
  onNotify,
}) => {
  const [copiedType, setCopiedType] = useState<'link' | 'code' | null>(null);
  const inviteLink = `${window.location.origin}/?ref=${inviteCode}`;
  const activeBuyersCount = invitedUsers.filter((u) => u.plans_count > 0).length;

  const copyText = async (type: 'link' | 'code', value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedType(type);
      onNotify(
        type === 'link'
          ? 'Invite link copied to clipboard.'
          : 'Invite code copied to clipboard.',
        'success'
      );
      setTimeout(() => setCopiedType(null), 1800);
    } catch {
      onNotify('Unable to copy to clipboard.', 'error');
    }
  };

  return (
    <div className="space-y-8">
      <div className="rounded-xl border border-slate-200 bg-white p-6 lg:p-8 space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div>
            <h1 className="text-2xl font-display font-bold text-slate-900">
              Invite &amp; Earn 10% Commission
            </h1>
            <p className="text-sm text-slate-500 mt-1 max-w-2xl">
              Share your direct invite code or invite link. Whenever someone signs up with your code and purchases any plan, 10% of the plan price is credited immediately to your balance.
            </p>
          </div>
        </div>

        {/* Direct Invite Code Display */}
        <div className="p-5 rounded-xl bg-emerald-50 border border-emerald-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="text-xs font-semibold text-emerald-700">
              Your Direct Invite Code
            </div>
            <div className="mt-1 text-3xl font-mono font-bold text-slate-900 tracking-widest">
              {inviteCode}
            </div>
          </div>
          <button
            type="button"
            onClick={() => copyText('code', inviteCode)}
            className="px-5 py-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
          >
            {copiedType === 'code' ? (
              <Check className="w-4 h-4" />
            ) : (
              <Copy className="w-4 h-4" />
            )}
            {copiedType === 'code' ? 'Code Copied' : 'Copy Invite Code'}
          </button>
        </div>

        <div className="pt-2 border-t border-slate-200">
          <label className="block text-xs font-medium text-slate-500 mb-1.5">
            Your Personal Invite Link
          </label>
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              readOnly
              value={inviteLink}
              onClick={(e) => (e.target as HTMLInputElement).select()}
              className="flex-1 px-3.5 py-2.5 rounded-lg bg-slate-50 border border-slate-300 text-sm font-mono text-slate-800 focus:outline-none"
            />
            <button
              type="button"
              onClick={() => copyText('link', inviteLink)}
              className="px-5 py-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-800 font-semibold text-sm flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
            >
              {copiedType === 'link' ? (
                <Check className="w-4 h-4 text-emerald-600" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
              {copiedType === 'link' ? 'Copied Link' : 'Copy Invite Link'}
            </button>
          </div>
        </div>
      </div>

      {/* Real-Time Referral KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Total Invited Users</span>
            <Users className="w-4 h-4 text-slate-400" />
          </div>
          <div className="mt-2 text-2xl font-mono font-bold text-slate-900 tabular-nums">
            {invitedUsers.length}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Invited Plan Buyers</span>
            <Award className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 text-2xl font-mono font-bold text-emerald-600 tabular-nums">
            {activeBuyersCount}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Total 10% Commission Earned</span>
            <Percent className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2 text-2xl font-mono font-bold text-slate-900 tabular-nums">
            {formatRs(totalReferralEarnings)}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <h2 className="text-base font-display font-semibold text-slate-900">
              Invited Users (Live Count)
            </h2>
            <span className="text-xs font-mono text-slate-500 tabular-nums">
              {invitedUsers.length} total
            </span>
          </div>
          {invitedUsers.length === 0 ? (
            <div className="p-6 text-xs text-slate-500">
              No users have signed up using your invite link yet.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-xs text-slate-500 bg-slate-50">
                    <th className="py-3 px-5 font-medium">User</th>
                    <th className="py-3 px-4 font-medium text-right">Plans</th>
                    <th className="py-3 px-4 font-medium text-right">Invested</th>
                    <th className="py-3 px-5 font-medium text-right">Joined</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {invitedUsers.map((inv) => (
                    <tr key={inv.id}>
                      <td className="py-3 px-5">
                        <div className="text-xs font-semibold text-slate-900">
                          {inv.name}
                        </div>
                        <div className="text-xs text-slate-500">{inv.email}</div>
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-800">
                        {inv.plans_count}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-600">
                        {formatRs(inv.total_invested)}
                      </td>
                      <td className="py-3 px-5 text-right text-xs font-mono text-slate-500 tabular-nums">
                        {formatDateTime(inv.created_at)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <h2 className="text-base font-display font-semibold text-slate-900">
              10% Referral Commissions
            </h2>
            <span className="text-xs font-mono text-slate-500 tabular-nums">
              {commissions.length} payouts
            </span>
          </div>
          {commissions.length === 0 ? (
            <div className="p-6 text-xs text-slate-500">
              Commissions appear automatically as soon as an invited user buys a plan.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-xs text-slate-500 bg-slate-50">
                    <th className="py-3 px-5 font-medium">Member</th>
                    <th className="py-3 px-4 font-medium">Plan</th>
                    <th className="py-3 px-4 font-medium text-right">10% Bonus</th>
                    <th className="py-3 px-5 font-medium text-right">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {commissions.map((comm) => (
                    <tr key={comm.id}>
                      <td className="py-3 px-5 text-xs font-semibold text-slate-900">
                        {comm.invited_user_name}
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-600">
                        {comm.plan_name} ({formatRs(comm.plan_price)})
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-semibold text-emerald-600 tabular-nums">
                        +{formatRs(comm.commission_amount)}
                      </td>
                      <td className="py-3 px-5 text-right text-xs font-mono text-slate-500 tabular-nums">
                        {formatDateTime(comm.created_at)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
