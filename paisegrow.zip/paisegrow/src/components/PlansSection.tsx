import React, { useState, useEffect } from 'react';
import {
  ArrowUpRight,
  AlertCircle,
  CheckCircle2,
  Eye,
  ExternalLink,
  Clock,
  X,
  PlayCircle,
} from 'lucide-react';
import {
  AD_DURATION_SECONDS,
  AD_REDIRECT_URL,
  INVESTMENT_PLANS,
  type InvestmentPlan,
} from '../shared/plans';
import { ApiError, fetchApi, formatDateTime, formatRs } from '../lib/api';
import type { UserPlanSubscription } from '../types';

interface PlansSectionProps {
  balance: number;
  activePlans: UserPlanSubscription[];
  onPlanPurchased: () => Promise<void>;
  onOpenDeposit: () => void;
  onNotify: (message: string, type?: 'success' | 'error') => void;
}

function getClaimAvailability(sub: UserPlanSubscription): {
  canClaim: boolean;
  reason: string;
} {
  if (sub.status !== 'active' || sub.days_credited >= sub.duration_days) {
    return { canClaim: false, reason: 'Plan 30-day cycle completed' };
  }
  if (sub.days_credited === 0) {
    return { canClaim: true, reason: 'Ready to claim today' };
  }
  const elapsedMs = Date.now() - new Date(sub.last_credited_at).getTime();
  const cooldownMs = 24 * 60 * 60 * 1000;
  if (elapsedMs >= cooldownMs) {
    return { canClaim: true, reason: 'Ready to claim today' };
  }
  const remainingMs = cooldownMs - elapsedMs;
  const hrs = Math.floor(remainingMs / (60 * 60 * 1000));
  const mins = Math.floor((remainingMs % (60 * 60 * 1000)) / (60 * 1000));
  return { canClaim: false, reason: `Next claim in ${hrs}h ${mins}m` };
}

export const PlansSection: React.FC<PlansSectionProps> = ({
  balance,
  activePlans,
  onPlanPurchased,
  onOpenDeposit,
  onNotify,
}) => {
  const [buyingPlanId, setBuyingPlanId] = useState<string | null>(null);
  const [insufficientPlan, setInsufficientPlan] = useState<InvestmentPlan | null>(
    null
  );
  const [failedPlanLogos, setFailedPlanLogos] = useState<Record<string, boolean>>(
    {}
  );
  const [viewMode, setViewMode] = useState<'all' | 'purchased'>('all');

  const [selectedPlan, setSelectedPlan] = useState<UserPlanSubscription | null>(
    null
  );
  const [adTaskActive, setAdTaskActive] = useState(false);
  const [adSecondsLeft, setAdSecondsLeft] = useState(AD_DURATION_SECONDS);
  const [claimSubmitting, setClaimSubmitting] = useState(false);

  useEffect(() => {
    if (!selectedPlan) return;
    const updated = activePlans.find((p) => p.id === selectedPlan.id);
    if (updated) {
      setSelectedPlan(updated);
    }
  }, [activePlans, selectedPlan]);

  useEffect(() => {
    if (!adTaskActive || adSecondsLeft <= 0) return;
    const timer = setInterval(() => {
      setAdSecondsLeft((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [adTaskActive, adSecondsLeft]);

  const handleBuyPlan = async (plan: InvestmentPlan) => {
    setInsufficientPlan(null);
    setBuyingPlanId(plan.id);
    try {
      const res = await fetchApi<{ message: string }>('/api/plans/buy', {
        method: 'POST',
        body: JSON.stringify({ planId: plan.id }),
      });
      onNotify(res.message, 'success');
      await onPlanPurchased();
      setViewMode('purchased');
    } catch (err) {
      if (err instanceof ApiError && err.data.insufficientFunds) {
        setInsufficientPlan(plan);
        onNotify('No enough money, please deposit.', 'error');
      } else {
        onNotify(
          err instanceof Error ? err.message : 'Unable to purchase plan.',
          'error'
        );
      }
    } finally {
      setBuyingPlanId(null);
    }
  };

  const handleStartAdClaim = async (sub: UserPlanSubscription) => {
    try {
      const res = await fetchApi<{ durationSeconds: number }>(
        `/api/plans/${sub.id}/start-claim`,
        { method: 'POST' }
      );
      setAdSecondsLeft(res.durationSeconds || AD_DURATION_SECONDS);
      setAdTaskActive(true);
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'Unable to start claim task.',
        'error'
      );
    }
  };

  const handleFinishAdClaim = async () => {
    if (!selectedPlan || adSecondsLeft > 0) return;
    setClaimSubmitting(true);
    try {
      const res = await fetchApi<{ message: string }>(
        `/api/plans/${selectedPlan.id}/claim`,
        { method: 'POST' }
      );
      onNotify(res.message, 'success');
      setAdTaskActive(false);
      await onPlanPurchased();
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'Unable to claim daily reward.',
        'error'
      );
    } finally {
      setClaimSubmitting(false);
    }
  };

  const closeModal = () => {
    setSelectedPlan(null);
    setAdTaskActive(false);
    setAdSecondsLeft(AD_DURATION_SECONDS);
  };

  return (
    <div className="space-y-6">
      {/* Top Switcher between Investment Plans & View Plan */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-1 p-1 rounded-lg bg-slate-100 border border-slate-200 w-fit">
          <button
            type="button"
            onClick={() => setViewMode('all')}
            className={`px-4 py-2 rounded-md text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
              viewMode === 'all'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Investment Plans
          </button>
          <button
            type="button"
            onClick={() => setViewMode('purchased')}
            className={`px-4 py-2 rounded-md text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
              viewMode === 'purchased'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            View Plan ({activePlans.length})
          </button>
        </div>

        <div className="text-xs text-slate-500">
          1 Daily Ad Task = Full Daily Plan Reward
        </div>
      </div>

      {/* Insufficient Balance Notice */}
      {insufficientPlan && (
        <div className="rounded-xl border border-amber-300 bg-amber-50 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-semibold text-amber-900">
                No enough money, please deposit.
              </div>
              <div className="text-xs text-amber-800 mt-0.5">
                {insufficientPlan.name} requires {formatRs(insufficientPlan.price)}, and your current balance is {formatRs(balance)}.
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={onOpenDeposit}
            className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-semibold text-xs whitespace-nowrap shrink-0 cursor-pointer"
          >
            Deposit Now
          </button>
        </div>
      )}

      {/* ALL PLANS VIEW */}
      {viewMode === 'all' && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5">
          {INVESTMENT_PLANS.map((plan) => {
            const isBuying = buyingPlanId === plan.id;
            const canAfford = balance >= plan.price;
            const netProfit = plan.totalEarning - plan.price;
            const existingSub = activePlans.find(
              (sub) => sub.plan_id === plan.id && sub.status === 'active'
            );

            return (
              <div
                key={plan.id}
                className="rounded-xl border border-slate-200 bg-white overflow-hidden flex flex-col justify-between transition-colors hover:border-slate-300 shadow-sm"
              >
                <div>
                  {/* Full-bleed edge-to-edge Plan Image with zero side bars */}
                  <div className="w-full aspect-[16/10] overflow-hidden border-b border-slate-200 bg-slate-950">
                    {!failedPlanLogos[plan.id] ? (
                      <img
                        src="/assets/aistudio/PaiseGrow_Plans__Premium_Growth_Logo_cb81d3ee.png"
                        alt={`${plan.name} Logo`}
                        referrerPolicy="no-referrer"
                        onError={() =>
                          setFailedPlanLogos((prev) => ({
                            ...prev,
                            [plan.id]: true,
                          }))
                        }
                        className="w-full h-full object-cover object-center"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center font-display font-bold text-lg text-emerald-400">
                        {plan.name}
                      </div>
                    )}
                  </div>

                  <div className="p-5">
                    <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
                      <span>{plan.tierLabel}</span>
                      <span aria-hidden="true">·</span>
                      <span>{plan.durationDays} Days</span>
                    </div>

                    <h2 className="mt-1.5 text-xl font-display font-bold text-slate-900 flex items-center gap-2">
                      <span
                        className="w-2.5 h-2.5 rounded-sm shrink-0"
                        style={{ backgroundColor: plan.accentColor }}
                      />
                      {plan.name}
                    </h2>

                    <div className="mt-3 pb-3 border-b border-slate-200">
                      <div className="text-xs text-slate-500">Plan Price</div>
                      <div className="text-3xl font-mono font-bold text-slate-900 tabular-nums mt-0.5">
                        {formatRs(plan.price)}
                      </div>
                    </div>

                    <dl className="mt-4 space-y-2 text-sm">
                      <div className="flex items-center justify-between">
                        <dt className="text-slate-500">Daily Earning (1 Ad)</dt>
                        <dd className="font-mono font-semibold text-emerald-600 tabular-nums">
                          {formatRs(plan.dailyEarning)}
                        </dd>
                      </div>
                      <div className="flex items-center justify-between">
                        <dt className="text-slate-500">Duration</dt>
                        <dd className="font-mono text-slate-800 tabular-nums">
                          {plan.durationDays} Days
                        </dd>
                      </div>
                      <div className="flex items-center justify-between">
                        <dt className="text-slate-500">Total Return</dt>
                        <dd className="font-mono font-semibold text-slate-900 tabular-nums">
                          {formatRs(plan.totalEarning)}
                        </dd>
                      </div>
                      <div className="flex items-center justify-between">
                        <dt className="text-slate-500">Net Profit</dt>
                        <dd className="font-mono font-medium text-emerald-600 tabular-nums">
                          +{formatRs(netProfit)}
                        </dd>
                      </div>
                    </dl>
                  </div>
                </div>

                <div className="p-5 pt-0 space-y-2">
                  <button
                    type="button"
                    disabled={isBuying}
                    onClick={() => handleBuyPlan(plan)}
                    className={`w-full py-2.5 px-4 rounded-lg font-semibold text-sm transition-colors flex items-center justify-center gap-1.5 cursor-pointer ${
                      canAfford
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300'
                    }`}
                  >
                    {isBuying ? 'Activating...' : `Buy ${plan.name}`}
                    <ArrowUpRight className="w-4 h-4" />
                  </button>

                  {existingSub && (
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedPlan(existingSub);
                        setAdTaskActive(false);
                      }}
                      className="w-full py-2 px-4 rounded-lg bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 font-semibold text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      View Plan
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* PURCHASED PLANS ("VIEW PLAN") SECTION */}
      {(viewMode === 'purchased' || activePlans.length > 0) && (
        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h2 className="text-base font-display font-semibold text-slate-900">
                View Plan — Purchased Subscriptions
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Open any purchased plan and click View Details to claim your daily reward
              </p>
            </div>
            <span className="text-xs font-mono text-slate-500 tabular-nums">
              {activePlans.length} {activePlans.length === 1 ? 'Plan' : 'Plans'}
            </span>
          </div>

          {activePlans.length === 0 ? (
            <div className="p-8 text-center">
              <Clock className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-sm font-medium text-slate-700">
                You have not purchased a plan yet
              </p>
              <p className="text-xs text-slate-500 mt-1">
                Buy a plan first to unlock your daily 1-ad reward claim.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-5">
              {activePlans.map((sub) => {
                const claimStatus = getClaimAvailability(sub);
                return (
                  <div
                    key={sub.id}
                    className="rounded-xl border border-slate-200 bg-slate-50 p-5 flex flex-col justify-between gap-4"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="text-base font-display font-bold text-slate-900">
                          {sub.plan_name}
                        </div>
                        <div className="text-xs text-slate-500 font-mono mt-0.5">
                          Invested: {formatRs(sub.price)} · Daily Reward:{' '}
                          <span className="text-emerald-600 font-semibold">
                            {formatRs(sub.daily_earning)}
                          </span>
                        </div>
                      </div>
                      <span
                        className={`text-xs font-semibold inline-flex items-center gap-1 ${
                          sub.status === 'active'
                            ? 'text-emerald-600'
                            : 'text-sky-600'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        {sub.status === 'active' ? 'Active' : 'Completed'}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 pt-3 border-t border-slate-200 text-xs">
                      <div>
                        <div className="text-slate-500">Days Claimed</div>
                        <div className="font-mono font-semibold text-slate-900 tabular-nums mt-0.5">
                          {sub.days_credited} / {sub.duration_days}
                        </div>
                      </div>
                      <div>
                        <div className="text-slate-500">Total Claimed</div>
                        <div className="font-mono font-semibold text-emerald-600 tabular-nums mt-0.5">
                          {formatRs(sub.days_credited * sub.daily_earning)}
                        </div>
                      </div>
                      <div>
                        <div className="text-slate-500">Status</div>
                        <div
                          className={`font-medium mt-0.5 ${
                            claimStatus.canClaim
                              ? 'text-emerald-700'
                              : 'text-slate-600'
                          }`}
                        >
                          {claimStatus.canClaim ? 'Claim Ready' : claimStatus.reason}
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setSelectedPlan(sub);
                        setAdTaskActive(false);
                      }}
                      className="w-full py-2.5 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Eye className="w-4 h-4" />
                      View Details
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* VIEW DETAILS & 15-SEC AD CLAIM MODAL */}
      {selectedPlan && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={closeModal}
        >
          <div
            className="w-full max-w-2xl rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-display font-bold text-slate-900">
                  {selectedPlan.plan_name} — Plan Details
                </h3>
                <p className="text-xs text-slate-500">
                  Purchased {formatDateTime(selectedPlan.purchased_at)}
                </p>
              </div>
              <button
                type="button"
                onClick={closeModal}
                aria-label="Close plan details"
                className="p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {!adTaskActive ? (
              <div className="p-6 space-y-6">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="text-xs text-slate-500">Plan Price</div>
                    <div className="font-mono font-bold text-slate-900 tabular-nums mt-1">
                      {formatRs(selectedPlan.price)}
                    </div>
                  </div>
                  <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="text-xs text-slate-500">1-Ad Reward</div>
                    <div className="font-mono font-bold text-emerald-600 tabular-nums mt-1">
                      {formatRs(selectedPlan.daily_earning)}
                    </div>
                  </div>
                  <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="text-xs text-slate-500">Days Claimed</div>
                    <div className="font-mono font-bold text-slate-900 tabular-nums mt-1">
                      {selectedPlan.days_credited} / {selectedPlan.duration_days}
                    </div>
                  </div>
                  <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
                    <div className="text-xs text-slate-500">Total Return</div>
                    <div className="font-mono font-bold text-slate-900 tabular-nums mt-1">
                      {formatRs(selectedPlan.total_earning)}
                    </div>
                  </div>
                </div>

                {(() => {
                  const status = getClaimAvailability(selectedPlan);
                  return status.canClaim ? (
                    <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 space-y-3">
                      <div className="text-sm font-semibold text-emerald-900">
                        Daily 1-Ad Task Ready — Earn {formatRs(selectedPlan.daily_earning)}
                      </div>
                      <p className="text-xs text-emerald-800 leading-relaxed">
                        Click <strong>Claim Today Money</strong> below to visit rollercoin.com for 15 seconds. Once the 15-second timer completes, {formatRs(selectedPlan.daily_earning)} will be credited to your wallet.
                      </p>
                      <button
                        type="button"
                        onClick={() => handleStartAdClaim(selectedPlan)}
                        className="w-full py-3 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <PlayCircle className="w-4 h-4" />
                        Claim Today Money ({formatRs(selectedPlan.daily_earning)})
                      </button>
                    </div>
                  ) : (
                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-center space-y-1">
                      <div className="text-sm font-semibold text-slate-800">
                        {status.reason}
                      </div>
                      <p className="text-xs text-slate-500">
                        You can claim {formatRs(selectedPlan.daily_earning)} once every 24 hours from 1 ad task.
                      </p>
                    </div>
                  );
                })()}
              </div>
            ) : (
              <div className="p-6 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-xl bg-slate-50 border border-slate-200">
                  <div>
                    <div className="text-xs text-slate-500">
                      Sponsored Ad Task · rollercoin.com
                    </div>
                    <div className="text-sm font-semibold text-slate-900 mt-0.5">
                      {adSecondsLeft > 0
                        ? `Stay on ad for ${adSecondsLeft}s to unlock ${formatRs(selectedPlan.daily_earning)}`
                        : `15 seconds completed! Click below to collect ${formatRs(selectedPlan.daily_earning)}`}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="px-3 py-1.5 rounded-lg bg-white border border-slate-300 font-mono font-bold text-sm text-emerald-600 tabular-nums">
                      {adSecondsLeft}s
                    </span>
                    <a
                      href={AD_REDIRECT_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1.5 rounded-lg bg-sky-50 border border-sky-200 text-sky-700 hover:bg-sky-100 text-xs font-medium inline-flex items-center gap-1"
                    >
                      Visit rollercoin.com
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>

                <div className="rounded-xl border border-slate-200 bg-slate-50 overflow-hidden">
                  <iframe
                    src={AD_REDIRECT_URL}
                    title="Sponsored Ad - rollercoin.com"
                    className="w-full h-64 bg-white"
                    sandbox="allow-scripts allow-same-origin allow-popups"
                  />
                  <div className="px-4 py-2 border-t border-slate-200 text-[11px] text-slate-500 flex items-center justify-between">
                    <span>Ad target: https://rollercoin.com</span>
                    <span>
                      If preview is blocked by site policy, use &ldquo;Visit rollercoin.com&rdquo; above while timer finishes.
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={adSecondsLeft > 0 || claimSubmitting}
                  onClick={handleFinishAdClaim}
                  className="w-full py-3 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-200 disabled:text-slate-500 text-white font-semibold text-sm transition-colors cursor-pointer"
                >
                  {claimSubmitting
                    ? 'Crediting Reward...'
                    : adSecondsLeft > 0
                    ? `Please wait ${adSecondsLeft} seconds...`
                    : `Collect ${formatRs(selectedPlan.daily_earning)} Now`}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
