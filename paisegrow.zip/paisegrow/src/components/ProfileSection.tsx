import React, { useState } from 'react';
import { ShieldCheck, KeyRound, User, Mail } from 'lucide-react';
import { fetchApi, formatDateTime, formatRs } from '../lib/api';
import type { UserProfile } from '../types';

interface ProfileSectionProps {
  user: UserProfile;
  onRefresh: () => Promise<void>;
  onNotify: (message: string, type?: 'success' | 'error') => void;
}

export const ProfileSection: React.FC<ProfileSectionProps> = ({
  user,
  onRefresh,
  onNotify,
}) => {
  const [name, setName] = useState(user.name);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);

  const handleUpdateName = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      const res = await fetchApi<{ message: string }>('/api/me/profile', {
        method: 'PATCH',
        body: JSON.stringify({ name }),
      });
      onNotify(res.message, 'success');
      await onRefresh();
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'Unable to update name.',
        'error'
      );
    } finally {
      setSavingProfile(false);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingPassword(true);
    try {
      const res = await fetchApi<{ message: string }>('/api/me/profile', {
        method: 'PATCH',
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      onNotify(res.message, 'success');
      setCurrentPassword('');
      setNewPassword('');
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'Unable to update password.',
        'error'
      );
    } finally {
      setSavingPassword(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="border-b border-slate-200 pb-5">
        <h1 className="text-2xl font-display font-bold text-slate-900">
          Account Profile
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          View your registered account identity, Gmail address, and password security settings.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-6 rounded-xl border border-slate-200 bg-white p-6 space-y-5">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-display font-semibold text-slate-900">
              Account Information
            </h2>
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-600">
              <ShieldCheck className="w-4 h-4" />
              Active Account
            </span>
          </div>

          <dl className="space-y-3 border-t border-slate-200 pt-4 text-sm">
            <div className="flex items-center justify-between py-2 border-b border-slate-100">
              <dt className="text-slate-500 flex items-center gap-2">
                <User className="w-4 h-4 text-slate-400" />
                Full Name
              </dt>
              <dd className="font-semibold text-slate-900">{user.name}</dd>
            </div>

            <div className="flex items-center justify-between py-2 border-b border-slate-100">
              <dt className="text-slate-500 flex items-center gap-2">
                <Mail className="w-4 h-4 text-slate-400" />
                Gmail / Email
              </dt>
              <dd className="font-mono text-slate-800">{user.email}</dd>
            </div>

            <div className="flex items-center justify-between py-2 border-b border-slate-100">
              <dt className="text-slate-500 flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-slate-400" />
                Password
              </dt>
              <dd className="font-mono text-slate-600 tracking-widest">
                ••••••••••••
              </dd>
            </div>

            <div className="flex items-center justify-between py-2 border-b border-slate-100">
              <dt className="text-slate-500">Invite Code</dt>
              <dd className="font-mono font-semibold text-emerald-600">
                {user.inviteCode}
              </dd>
            </div>

            <div className="flex items-center justify-between py-2 border-b border-slate-100">
              <dt className="text-slate-500">Current Balance</dt>
              <dd className="font-mono font-semibold text-slate-900 tabular-nums">
                {formatRs(user.balance)}
              </dd>
            </div>

            <div className="flex items-center justify-between py-2">
              <dt className="text-slate-500">Member Since</dt>
              <dd className="font-mono text-xs text-slate-500 tabular-nums">
                {formatDateTime(user.createdAt)}
              </dd>
            </div>
          </dl>

          <form
            onSubmit={handleUpdateName}
            className="pt-4 border-t border-slate-200 space-y-3"
          >
            <label className="block text-xs font-medium text-slate-700">
              Update Display Name
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                required
                minLength={2}
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="flex-1 px-3.5 py-2 rounded-lg bg-white border border-slate-300 text-sm text-slate-900 focus:outline-none focus:border-emerald-600"
              />
              <button
                type="submit"
                disabled={savingProfile}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-xs whitespace-nowrap cursor-pointer"
              >
                {savingProfile ? 'Saving...' : 'Save Name'}
              </button>
            </div>
          </form>
        </div>

        <form
          onSubmit={handleUpdatePassword}
          className="lg:col-span-6 rounded-xl border border-slate-200 bg-white p-6 space-y-4"
        >
          <div>
            <h2 className="text-lg font-display font-semibold text-slate-900">
              Change Password
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Update your account password anytime. Passwords are encrypted securely on the server.
            </p>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Current Password
            </label>
            <input
              type="password"
              required
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="Enter current password"
              className="w-full px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 text-sm text-slate-900 focus:outline-none focus:border-emerald-600"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              New Password
            </label>
            <input
              type="password"
              required
              minLength={6}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Minimum 6 characters"
              className="w-full px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 text-sm text-slate-900 focus:outline-none focus:border-emerald-600"
            />
          </div>

          <button
            type="submit"
            disabled={savingPassword}
            className="w-full py-2.5 px-4 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm transition-colors cursor-pointer"
          >
            {savingPassword ? 'Updating...' : 'Update Password'}
          </button>
        </form>
      </div>
    </div>
  );
};
