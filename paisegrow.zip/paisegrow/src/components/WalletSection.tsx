import React, { useState, useRef } from 'react';
import {
  Copy,
  Check,
  Upload,
  Image as ImageIcon,
  ArrowDownCircle,
  ArrowUpCircle,
  Ticket,
  X,
} from 'lucide-react';
import {
  DEPOSIT_ACCOUNT,
  MIN_DEPOSIT_AMOUNT,
  MIN_WITHDRAW_AMOUNT,
  WITHDRAWAL_BANKS,
  type WithdrawalBank,
} from '../shared/plans';
import { fetchApi, formatDateTime, formatRs } from '../lib/api';
import type {
  DepositRecord,
  PromoRedemptionRecord,
  WithdrawalRecord,
} from '../types';

export type WalletTab = 'deposit' | 'withdraw' | 'promo';

interface WalletSectionProps {
  initialTab?: WalletTab;
  balance: number;
  deposits: DepositRecord[];
  withdrawals: WithdrawalRecord[];
  promoRedemptions: PromoRedemptionRecord[];
  onRefresh: () => Promise<void>;
  onNotify: (message: string, type?: 'success' | 'error') => void;
}

export const WalletSection: React.FC<WalletSectionProps> = ({
  initialTab = 'deposit',
  balance,
  deposits,
  withdrawals,
  promoRedemptions,
  onRefresh,
  onNotify,
}) => {
  const [activeTab, setActiveTab] = useState<WalletTab>(initialTab);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const [depositAmount, setDepositAmount] = useState('');
  const [transactionRef, setTransactionRef] = useState('');
  const [screenshotFile, setScreenshotFile] = useState<File | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [depositLoading, setDepositLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [bankName, setBankName] = useState<WithdrawalBank>('Easypaisa');
  const [accountName, setAccountName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawLoading, setWithdrawLoading] = useState(false);

  const [promoCode, setPromoCode] = useState('');
  const [promoLoading, setPromoLoading] = useState(false);

  React.useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  const copyValue = async (label: string, value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedField(label);
      setTimeout(() => setCopiedField(null), 1800);
    } catch {
      onNotify('Unable to copy to clipboard.', 'error');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      onNotify('Please select a valid image file from your gallery.', 'error');
      return;
    }
    setScreenshotFile(file);
    const reader = new FileReader();
    reader.onload = () => setScreenshotPreview(String(reader.result || ''));
    reader.readAsDataURL(file);
  };

  const handleDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!screenshotFile) {
      onNotify('Please upload your payment receipt screenshot from your gallery.', 'error');
      return;
    }

    setDepositLoading(true);
    try {
      const formData = new FormData();
      formData.append('amount', depositAmount);
      formData.append('transactionRef', transactionRef);
      formData.append('screenshot', screenshotFile);

      const res = await fetchApi<{ message: string }>('/api/deposits', {
        method: 'POST',
        body: formData,
      });

      onNotify(res.message, 'success');
      setDepositAmount('');
      setTransactionRef('');
      setScreenshotFile(null);
      setScreenshotPreview(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      await onRefresh();
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'Unable to submit deposit.',
        'error'
      );
    } finally {
      setDepositLoading(false);
    }
  };

  const handleWithdrawSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawLoading(true);
    try {
      const res = await fetchApi<{ message: string }>('/api/withdrawals', {
        method: 'POST',
        body: JSON.stringify({
          bankName,
          accountName,
          accountNumber,
          amount: Number(withdrawAmount),
        }),
      });
      onNotify(res.message, 'success');
      setAccountName('');
      setAccountNumber('');
      setWithdrawAmount('');
      await onRefresh();
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'Unable to submit withdrawal.',
        'error'
      );
    } finally {
      setWithdrawLoading(false);
    }
  };

  const handlePromoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPromoLoading(true);
    try {
      const res = await fetchApi<{ message: string }>('/api/promos/redeem', {
        method: 'POST',
        body: JSON.stringify({ code: promoCode }),
      });
      onNotify(res.message, 'success');
      setPromoCode('');
      await onRefresh();
    } catch (err) {
      onNotify(
        err instanceof Error ? err.message : 'Unable to redeem promo code.',
        'error'
      );
    } finally {
      setPromoLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <h1 className="text-2xl font-display font-bold text-slate-900">
            Wallet &amp; Transactions
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Available Balance:{' '}
            <span className="font-mono font-semibold text-emerald-600 tabular-nums">
              {formatRs(balance)}
            </span>
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 rounded-lg bg-slate-100 border border-slate-200 self-start">
          <button
            type="button"
            onClick={() => setActiveTab('deposit')}
            className={`px-4 py-2 rounded-md text-xs font-medium flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'deposit'
                ? 'bg-emerald-600 text-white font-semibold shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ArrowDownCircle className="w-4 h-4" />
            Deposit
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('withdraw')}
            className={`px-4 py-2 rounded-md text-xs font-medium flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'withdraw'
                ? 'bg-emerald-600 text-white font-semibold shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ArrowUpCircle className="w-4 h-4" />
            Withdraw
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('promo')}
            className={`px-4 py-2 rounded-md text-xs font-medium flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'promo'
                ? 'bg-emerald-600 text-white font-semibold shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Ticket className="w-4 h-4" />
            Promo Code
          </button>
        </div>
      </div>

      {/* DEPOSIT TAB */}
      {activeTab === 'deposit' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-6 space-y-5">
            <div>
              <h2 className="text-lg font-display font-semibold text-slate-900">
                Official Deposit Account
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Send your deposit amount to the account below, then upload your payment screenshot from your gallery.
              </p>
            </div>

            <div className="space-y-3 border-t border-slate-200 pt-4">
              <div className="flex items-center justify-between py-2 border-b border-slate-100">
                <span className="text-xs text-slate-500">Bank / Wallet</span>
                <span className="text-sm font-semibold text-emerald-600">
                  {DEPOSIT_ACCOUNT.bankName}
                </span>
              </div>

              <div className="flex items-center justify-between py-2 border-b border-slate-100">
                <span className="text-xs text-slate-500">Account Name</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-slate-900">
                    {DEPOSIT_ACCOUNT.accountName}
                  </span>
                  <button
                    type="button"
                    onClick={() => copyValue('name', DEPOSIT_ACCOUNT.accountName)}
                    className="p-1.5 rounded bg-slate-100 text-slate-600 hover:text-slate-900 cursor-pointer"
                    aria-label="Copy account name"
                  >
                    {copiedField === 'name' ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between py-2">
                <span className="text-xs text-slate-500">Account Number</span>
                <div className="flex items-center gap-2">
                  <span className="text-base font-mono font-bold text-slate-900 tabular-nums">
                    {DEPOSIT_ACCOUNT.accountNumber}
                  </span>
                  <button
                    type="button"
                    onClick={() => copyValue('number', DEPOSIT_ACCOUNT.accountNumber)}
                    className="p-1.5 rounded bg-slate-100 text-slate-600 hover:text-slate-900 cursor-pointer"
                    aria-label="Copy account number"
                  >
                    {copiedField === 'number' ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>

          <form
            onSubmit={handleDepositSubmit}
            className="lg:col-span-7 rounded-xl border border-slate-200 bg-white p-6 space-y-5"
          >
            <h2 className="text-lg font-display font-semibold text-slate-900">
              Submit Deposit Proof
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Deposit Amount (Min Rs. {MIN_DEPOSIT_AMOUNT})
                </label>
                <input
                  type="number"
                  min={MIN_DEPOSIT_AMOUNT}
                  step="1"
                  required
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  placeholder={`Minimum Rs. ${MIN_DEPOSIT_AMOUNT}`}
                  className="w-full px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 text-sm font-mono text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Transaction ID / Reference (Optional)
                </label>
                <input
                  type="text"
                  value={transactionRef}
                  onChange={(e) => setTransactionRef(e.target.value)}
                  placeholder="e.g. TID-984321"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 text-sm font-mono text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Upload Payment Screenshot (From Gallery)
              </label>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
                id="deposit-receipt-upload"
              />

              {!screenshotPreview ? (
                <label
                  htmlFor="deposit-receipt-upload"
                  className="flex flex-col items-center justify-center gap-2 p-6 rounded-xl border border-dashed border-slate-300 bg-slate-50 hover:border-emerald-500 transition-colors cursor-pointer"
                >
                  <Upload className="w-6 h-6 text-emerald-600" />
                  <span className="text-sm font-medium text-slate-700">
                    Click to select payment picture from gallery
                  </span>
                  <span className="text-xs text-slate-500">
                    PNG, JPG, or WEBP up to 5 MB
                  </span>
                </label>
              ) : (
                <div className="relative rounded-xl border border-slate-200 bg-slate-50 p-3 flex items-center gap-4">
                  <img
                    src={screenshotPreview}
                    alt="Receipt preview"
                    className="w-20 h-20 object-cover rounded-lg border border-slate-200"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-slate-900 truncate">
                      {screenshotFile?.name}
                    </div>
                    <div className="text-xs text-emerald-600 mt-0.5 flex items-center gap-1">
                      <ImageIcon className="w-3.5 h-3.5" />
                      Receipt image attached
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setScreenshotFile(null);
                      setScreenshotPreview(null);
                      if (fileInputRef.current) fileInputRef.current.value = '';
                    }}
                    className="p-2 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-200 cursor-pointer"
                    aria-label="Remove screenshot"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={depositLoading}
              className="w-full py-3 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-sm transition-colors cursor-pointer"
            >
              {depositLoading ? 'Uploading Deposit...' : 'Submit Deposit Request'}
            </button>
          </form>
        </div>
      )}

      {/* WITHDRAW TAB */}
      {activeTab === 'withdraw' && (
        <form
          onSubmit={handleWithdrawSubmit}
          className="max-w-2xl rounded-xl border border-slate-200 bg-white p-6 space-y-5"
        >
          <div>
            <h2 className="text-lg font-display font-semibold text-slate-900">
              Request Withdrawal
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Select your preferred bank or mobile wallet and enter your exact account details.
            </p>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-2">
              Select Bank / Mobile Wallet
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {WITHDRAWAL_BANKS.map((bank) => (
                <button
                  key={bank}
                  type="button"
                  onClick={() => setBankName(bank)}
                  className={`py-2.5 px-3 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
                    bankName === bank
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-700'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-300'
                  }`}
                >
                  {bank}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Account Holder Name
              </label>
              <input
                type="text"
                required
                value={accountName}
                onChange={(e) => setAccountName(e.target.value)}
                placeholder="Enter account title"
                className="w-full px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Account Number
              </label>
              <input
                type="text"
                required
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                placeholder="03XXXXXXXXX"
                className="w-full px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 text-sm font-mono text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-600"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Withdrawal Amount (Min Rs. {MIN_WITHDRAW_AMOUNT})
            </label>
            <input
              type="number"
              min={MIN_WITHDRAW_AMOUNT}
              max={balance > 0 ? balance : undefined}
              step="1"
              required
              value={withdrawAmount}
              onChange={(e) => setWithdrawAmount(e.target.value)}
              placeholder={`Min Rs. ${MIN_WITHDRAW_AMOUNT} · Available: Rs. ${balance}`}
              className="w-full px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 text-sm font-mono text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-600"
            />
          </div>

          <button
            type="submit"
            disabled={withdrawLoading}
            className="w-full py-3 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-sm transition-colors cursor-pointer"
          >
            {withdrawLoading
              ? 'Submitting Withdrawal...'
              : `Withdraw to ${bankName}`}
          </button>
        </form>
      )}

      {/* PROMO CODE TAB */}
      {activeTab === 'promo' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <form
            onSubmit={handlePromoSubmit}
            className="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-6 space-y-4"
          >
            <h2 className="text-lg font-display font-semibold text-slate-900">
              Redeem Promo Code
            </h2>
            <p className="text-xs text-slate-500">
              Enter an active promo code issued by PaiseGrow administration to claim bonus funds directly into your balance.
            </p>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">
                Promo Code
              </label>
              <input
                type="text"
                required
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                placeholder="ENTER CODE"
                className="w-full px-3.5 py-2.5 rounded-lg bg-white border border-slate-300 text-sm font-mono uppercase tracking-wider text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-600"
              />
            </div>
            <button
              type="submit"
              disabled={promoLoading}
              className="w-full py-3 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-sm transition-colors cursor-pointer"
            >
              {promoLoading ? 'Checking Code...' : 'Redeem Promo Code'}
            </button>
          </form>

          <div className="lg:col-span-7 rounded-xl border border-slate-200 bg-white overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200">
              <h3 className="text-base font-display font-semibold text-slate-900">
                Redeemed Promo History
              </h3>
            </div>
            {promoRedemptions.length === 0 ? (
              <div className="p-6 text-xs text-slate-500">
                No promo codes redeemed yet.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead>
                    <tr className="border-b border-slate-200 text-xs text-slate-500 bg-slate-50">
                      <th className="py-3 px-6 font-medium">Code</th>
                      <th className="py-3 px-4 font-medium text-right">Bonus</th>
                      <th className="py-3 px-6 font-medium text-right">Redeemed At</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {promoRedemptions.map((item) => (
                      <tr key={item.id}>
                        <td className="py-3 px-6 font-mono font-semibold text-slate-900">
                          {item.code}
                        </td>
                        <td className="py-3 px-4 text-right font-mono text-emerald-600 tabular-nums">
                          +{formatRs(item.reward_amount)}
                        </td>
                        <td className="py-3 px-6 text-right text-xs font-mono text-slate-500 tabular-nums">
                          {formatDateTime(item.redeemed_at)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Real-Time Deposit & Withdrawal History */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-base font-display font-semibold text-slate-900">
              Deposit History
            </h3>
            <span className="text-xs font-mono text-slate-500 tabular-nums">
              {deposits.length} records
            </span>
          </div>
          {deposits.length === 0 ? (
            <div className="p-6 text-xs text-slate-500">No deposits submitted yet.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-xs text-slate-500 bg-slate-50">
                    <th className="py-3 px-5 font-medium">Amount</th>
                    <th className="py-3 px-4 font-medium">Status</th>
                    <th className="py-3 px-4 font-medium">Receipt</th>
                    <th className="py-3 px-5 font-medium text-right">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {deposits.map((dep) => (
                    <tr key={dep.id}>
                      <td className="py-3 px-5 font-mono font-semibold text-slate-900 tabular-nums">
                        {formatRs(dep.amount)}
                      </td>
                      <td className="py-3 px-4 text-xs font-semibold capitalize">
                        <span
                          className={
                            dep.status === 'approved'
                              ? 'text-emerald-600'
                              : dep.status === 'rejected'
                              ? 'text-red-600'
                              : 'text-amber-600'
                          }
                        >
                          {dep.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-xs">
                        <a
                          href={dep.screenshot_path}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sky-600 hover:underline font-medium"
                        >
                          View Image
                        </a>
                      </td>
                      <td className="py-3 px-5 text-right text-xs font-mono text-slate-500 tabular-nums">
                        {formatDateTime(dep.created_at)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-base font-display font-semibold text-slate-900">
              Withdrawal History
            </h3>
            <span className="text-xs font-mono text-slate-500 tabular-nums">
              {withdrawals.length} records
            </span>
          </div>
          {withdrawals.length === 0 ? (
            <div className="p-6 text-xs text-slate-500">
              No withdrawal requests yet.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-xs text-slate-500 bg-slate-50">
                    <th className="py-3 px-5 font-medium">Bank / Account</th>
                    <th className="py-3 px-4 font-medium text-right">Amount</th>
                    <th className="py-3 px-4 font-medium">Status</th>
                    <th className="py-3 px-5 font-medium text-right">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {withdrawals.map((wd) => (
                    <tr key={wd.id}>
                      <td className="py-3 px-5">
                        <div className="text-xs font-semibold text-slate-900">
                          {wd.bank_name}
                        </div>
                        <div className="text-xs text-slate-500 font-mono">
                          {wd.account_name} · {wd.account_number}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-semibold text-slate-900 tabular-nums">
                        {formatRs(wd.amount)}
                      </td>
                      <td className="py-3 px-4 text-xs font-semibold capitalize">
                        <span
                          className={
                            wd.status === 'approved'
                              ? 'text-emerald-600'
                              : wd.status === 'rejected'
                              ? 'text-red-600'
                              : 'text-amber-600'
                          }
                        >
                          {wd.status}
                        </span>
                      </td>
                      <td className="py-3 px-5 text-right text-xs font-mono text-slate-500 tabular-nums">
                        {formatDateTime(wd.created_at)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
