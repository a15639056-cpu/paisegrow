export interface InvestmentPlan {
  id: 'bronze' | 'platinum' | 'diamond' | 'gold';
  name: string;
  tierLabel: string;
  price: number;
  dailyEarning: number;
  durationDays: number;
  totalEarning: number;
  accentColor: string;
  description: string;
}

export const INVESTMENT_PLANS: InvestmentPlan[] = [
  {
    id: 'bronze',
    name: 'Bronze Plan',
    tierLabel: 'Starter Tier',
    price: 250,
    dailyEarning: 15,
    durationDays: 30,
    totalEarning: 450,
    accentColor: '#cd7f32',
    description: 'Earn Rs. 15 daily from 1 ad task for 30 days.',
  },
  {
    id: 'platinum',
    name: 'Platinum Plan',
    tierLabel: 'Growth Tier',
    price: 1500,
    dailyEarning: 110,
    durationDays: 30,
    totalEarning: 3300,
    accentColor: '#38bdf8',
    description: 'Earn Rs. 110 daily from 1 ad task for 30 days.',
  },
  {
    id: 'diamond',
    name: 'Diamond Plan',
    tierLabel: 'Pro Tier',
    price: 3000,
    dailyEarning: 210,
    durationDays: 30,
    totalEarning: 6300,
    accentColor: '#a855f7',
    description: 'Earn Rs. 210 daily from 1 ad task for 30 days.',
  },
  {
    id: 'gold',
    name: 'Gold Plan',
    tierLabel: 'Executive Tier',
    price: 5000,
    dailyEarning: 350,
    durationDays: 30,
    totalEarning: 10500,
    accentColor: '#f59e0b',
    description: 'Earn Rs. 350 daily from 1 ad task for 30 days.',
  },
];

export const MIN_DEPOSIT_AMOUNT = 250;
export const MIN_WITHDRAW_AMOUNT = 250;

export const AD_REDIRECT_URL = 'https://rollercoin.com';
export const AD_DURATION_SECONDS = 15;

export const DEPOSIT_ACCOUNT = {
  bankName: 'Easypaisa',
  accountName: 'HUMAIRA ARIF',
  accountNumber: '03215694481',
} as const;

export const WITHDRAWAL_BANKS = [
  'Easypaisa',
  'JazzCash',
  'NayaPay',
  'SadaPay',
  'UPaisa',
] as const;

export type WithdrawalBank = (typeof WITHDRAWAL_BANKS)[number];

export const WHATSAPP_CHANNEL_URL =
  'https://whatsapp.com/channel/0029VbE1BCEGk1FkJmuFOO1T';

export const REFERRAL_COMMISSION_RATE = 0.1; // 10%
