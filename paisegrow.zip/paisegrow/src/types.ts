export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  inviteCode: string;
  balance: number;
  totalEarned: number;
  totalReferralEarnings: number;
  emailVerified: boolean;
  createdAt: string;
}

export interface UserPlanSubscription {
  id: string;
  user_id: string;
  plan_id: string;
  plan_name: string;
  price: number;
  daily_earning: number;
  total_earning: number;
  duration_days: number;
  days_credited: number;
  status: 'active' | 'completed';
  purchased_at: string;
  last_credited_at: string;
}

export interface DepositRecord {
  id: string;
  user_id: string;
  amount: number;
  method: string;
  transaction_ref: string;
  screenshot_path: string;
  status: 'pending' | 'approved' | 'rejected';
  admin_note: string;
  created_at: string;
  reviewed_at: string | null;
  user_name?: string;
  user_email?: string;
}

export interface WithdrawalRecord {
  id: string;
  user_id: string;
  bank_name: string;
  account_name: string;
  account_number: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  admin_note: string;
  created_at: string;
  reviewed_at: string | null;
  user_name?: string;
  user_email?: string;
}

export interface InvitedUserRecord {
  id: string;
  name: string;
  email: string;
  email_verified: number;
  created_at: string;
  plans_count: number;
  total_invested: number;
}

export interface ReferralCommissionRecord {
  id: string;
  inviter_id: string;
  invited_user_id: string;
  invited_user_name: string;
  plan_name: string;
  plan_price: number;
  commission_amount: number;
  created_at: string;
}

export interface PromoRedemptionRecord {
  id: string;
  promo_id: string;
  user_id: string;
  code: string;
  reward_amount: number;
  redeemed_at: string;
}

export interface DashboardSnapshot {
  user: UserProfile;
  activePlans: UserPlanSubscription[];
  deposits: DepositRecord[];
  withdrawals: WithdrawalRecord[];
  invitedUsers: InvitedUserRecord[];
  commissions: ReferralCommissionRecord[];
  promoRedemptions: PromoRedemptionRecord[];
}

export interface AdminUserRecord {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  invite_code: string;
  balance: number;
  total_earned: number;
  total_referral_earnings: number;
  email_verified: number;
  is_banned: number;
  created_at: string;
  total_plans_count: number;
  active_plans_count: number;
  total_invested: number;
  invited_count: number;
}

export interface AdminPromoRecord {
  id: string;
  code: string;
  reward_amount: number;
  max_uses: number;
  used_count: number;
  expires_at: string;
  is_active: number;
  created_at: string;
}

export interface AdminOverviewData {
  stats: {
    totalUsers: number;
    buyersCount: number;
    nonBuyersCount: number;
    bannedCount: number;
    pendingDeposits: number;
    pendingWithdrawals: number;
    totalDepositedApproved: number;
    totalWithdrawnApproved: number;
  };
  users: AdminUserRecord[];
  deposits: DepositRecord[];
  withdrawals: WithdrawalRecord[];
  promoCodes: AdminPromoRecord[];
}

export interface SandboxEmailPreview {
  to: string;
  subject: string;
  code: string;
  text: string;
}
